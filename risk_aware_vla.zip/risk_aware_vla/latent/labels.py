"""
Stage 3 — Ground-Truth Latent Label Generator
Computes Zt = [ol, oc, or, pcoll, TTC, pcross, dped, v, elane, yaw_rate]
from CARLA simulator state.
"""
from __future__ import annotations
import numpy as np
from dataclasses import dataclass, field
from typing import Optional, List
import math


@dataclass
class CarlaState:
    """Subset of CARLA world state at one time step."""
    ego_velocity: float                   # m/s
    ego_yaw_rate: float                   # rad/s
    ego_location: np.ndarray             # [x, y, z] in CARLA world coords
    ego_heading: float                   # radians

    pedestrians: List[dict] = field(default_factory=list)
    # each dict: {id, location:[x,y,z], velocity:[vx,vy], bbox, occluded:bool}

    vehicles: List[dict] = field(default_factory=list)
    # each dict: {id, location:[x,y,z], velocity:[vx,vy]}

    collision_occurred: bool = False
    route_waypoints: List[np.ndarray] = field(default_factory=list)

    # Optional: CARLA spectator / sensor depth
    depth_buffer: Optional[np.ndarray] = None


@dataclass
class LatentLabel:
    """The structured latent vector Zt."""
    ol: float      # left occlusion score  [0, 1]
    oc: float      # center occlusion score [0, 1]
    or_: float     # right occlusion score  [0, 1]
    pcoll: float   # short-horizon collision probability [0, 1]
    TTC: float     # time-to-collision (seconds, clipped)
    pcross: float  # pedestrian crossing probability [0, 1]
    dped: float    # distance to nearest relevant pedestrian (m)
    v: float       # ego speed (m/s)
    elane: float   # lane-center error (normalised, signed)
    yaw_rate: float  # yaw rate (rad/s, normalised)

    def to_array(self) -> np.ndarray:
        return np.array([
            self.ol, self.oc, self.or_, self.pcoll,
            self.TTC, self.pcross, self.dped,
            self.v, self.elane, self.yaw_rate,
        ], dtype=np.float32)

    @staticmethod
    def from_array(arr: np.ndarray) -> "LatentLabel":
        return LatentLabel(
            ol=arr[0], oc=arr[1], or_=arr[2], pcoll=arr[3],
            TTC=arr[4], pcross=arr[5], dped=arr[6],
            v=arr[7], elane=arr[8], yaw_rate=arr[9],
        )

    @staticmethod
    def dim() -> int:
        return 10

    @staticmethod
    def names() -> List[str]:
        return ["ol", "oc", "or", "pcoll", "TTC", "pcross", "dped", "v", "elane", "yaw_rate"]

    @staticmethod
    def prob_indices() -> List[int]:
        """Indices that represent probabilities (use BCE loss)."""
        return [0, 1, 2, 3, 5]


# ============================================================
# Label Computer
# ============================================================

class LatentLabelComputer:
    """
    Computes ground-truth latent labels from CARLA state.
    All formulas are documented inline.
    """

    def __init__(
        self,
        ttc_max: float = 10.0,
        dped_max: float = 50.0,
        speed_max: float = 15.0,
        yaw_rate_max: float = 1.5,
        sector_angle_deg: float = 45.0,
        # pcoll weights
        alpha1: float = 1.0,
        alpha2: float = 0.8,
        alpha3: float = 0.6,
        alpha4: float = 0.3,
        alpha5: float = 0.5,
    ):
        self.ttc_max = ttc_max
        self.dped_max = dped_max
        self.speed_max = speed_max
        self.yaw_rate_max = yaw_rate_max
        self.sector_angle = math.radians(sector_angle_deg)
        self.a1, self.a2, self.a3, self.a4, self.a5 = alpha1, alpha2, alpha3, alpha4, alpha5

    # ------------------------------------------------------------------
    def compute(
        self,
        state: CarlaState,
        pcross: float = 0.0,
        lane_error_norm: float = 0.0,
    ) -> LatentLabel:
        """
        Main entry point.
        pcross is supplied externally from the PIP model or CARLA event proxy.
        lane_error_norm is supplied externally from the lane detector.
        """
        # --- occlusion scores -----------------------------------------
        ol, oc, or_ = self._occlusion_scores(state)

        # --- nearest pedestrian distance ------------------------------
        dped = self._nearest_pedestrian_distance(state)

        # --- TTC ------------------------------------------------------
        TTC = self._time_to_collision(state)

        # --- pcoll (short-horizon collision probability) --------------
        pcoll = self._compute_pcoll(TTC, pcross, oc, state.ego_velocity, dped)

        # --- normalise scalars ----------------------------------------
        v_norm = float(np.clip(state.ego_velocity / self.speed_max, 0.0, 1.0))
        yr_norm = float(np.clip(state.ego_yaw_rate / self.yaw_rate_max, -1.0, 1.0))
        ttc_norm = float(np.clip(TTC / self.ttc_max, 0.0, 1.0))
        dped_norm = float(np.clip(dped / self.dped_max, 0.0, 1.0))

        return LatentLabel(
            ol=float(ol),
            oc=float(oc),
            or_=float(or_),
            pcoll=float(pcoll),
            TTC=ttc_norm,
            pcross=float(pcross),
            dped=dped_norm,
            v=v_norm,
            elane=float(lane_error_norm),
            yaw_rate=yr_norm,
        )

    # ------------------------------------------------------------------
    def _occlusion_scores(self, state: CarlaState) -> tuple:
        """
        Geometry-based occlusion scores for left / center / right sectors.
        A pedestrian contributes to the occlusion score of a sector if it
        is marked as occluded (by CARLA's raycast) AND lies in that sector.
        """
        ol = oc = or_ = 0.0
        ego_loc = state.ego_location[:2]
        heading = state.ego_heading

        for ped in state.pedestrians:
            if not ped.get("occluded", False):
                continue
            ped_loc = np.array(ped["location"][:2])
            diff = ped_loc - ego_loc
            dist = np.linalg.norm(diff) + 1e-6
            if dist > self.dped_max:
                continue
            angle = math.atan2(diff[1], diff[0]) - heading
            angle = (angle + math.pi) % (2 * math.pi) - math.pi  # wrap to [-π, π]
            # weight by proximity (closer = higher risk)
            weight = float(np.clip(1.0 - dist / self.dped_max, 0, 1))
            if angle < -self.sector_angle:
                ol = min(1.0, ol + weight)
            elif angle > self.sector_angle:
                or_ = min(1.0, or_ + weight)
            else:
                oc = min(1.0, oc + weight)

        return ol, oc, or_

    def _nearest_pedestrian_distance(self, state: CarlaState) -> float:
        """Distance to nearest pedestrian in the scene."""
        ego_loc = state.ego_location[:2]
        dists = []
        for ped in state.pedestrians:
            d = float(np.linalg.norm(np.array(ped["location"][:2]) - ego_loc))
            dists.append(d)
        return float(min(dists)) if dists else float(self.dped_max)

    def _time_to_collision(self, state: CarlaState) -> float:
        """
        Simplified TTC: project all vehicles onto ego heading,
        take the minimum positive TTC.
        """
        ego_loc = state.ego_location[:2]
        ego_v = state.ego_velocity
        heading = state.ego_heading
        heading_vec = np.array([math.cos(heading), math.sin(heading)])

        min_ttc = self.ttc_max
        for veh in state.vehicles:
            veh_loc = np.array(veh["location"][:2])
            diff = veh_loc - ego_loc
            # longitudinal distance
            lon_dist = float(np.dot(diff, heading_vec))
            if lon_dist <= 0 or lon_dist > 40:
                continue
            # relative longitudinal velocity
            veh_vel = np.array(veh.get("velocity", [0, 0]))
            rel_v = ego_v - float(np.dot(veh_vel, heading_vec))
            if rel_v <= 0:
                continue
            ttc = lon_dist / (rel_v + 1e-6)
            min_ttc = min(min_ttc, ttc)

        return float(min_ttc)

    def _compute_pcoll(
        self,
        TTC: float,
        pcross: float,
        oc: float,
        speed: float,
        dped: float,
    ) -> float:
        """
        Short-horizon collision probability proxy:
        pcoll = σ(α1/TTC + α2·pcross + α3·oc + α4·v + α5/dped)
        """
        eps = 1e-6
        v_norm = float(np.clip(speed / self.speed_max, 0, 1))
        logit = (
            self.a1 / (TTC + eps)
            + self.a2 * pcross
            + self.a3 * oc
            + self.a4 * v_norm
            + self.a5 / (dped + eps)
        )
        return float(1.0 / (1.0 + math.exp(-logit)))
