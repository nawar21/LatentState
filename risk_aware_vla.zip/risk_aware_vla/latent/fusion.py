"""
Stage 5 — Multimodal Latent Fusion Head
Fuses: DINOv2 features, YOLO outputs, depth features, lane features,
       pcross, ego speed, yaw rate → predicted latent vector Zhat.
Includes noise-aware confidence weighting.
"""
from __future__ import annotations
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Optional, Tuple, List
from dataclasses import dataclass


# ============================================================
# Feature Encoders for each modality
# ============================================================

class YOLOEncoder(nn.Module):
    """Encode raw YOLO detections into a fixed-size feature."""

    def __init__(self, max_dets: int = 20, out_dim: int = 64):
        super().__init__()
        # Each detection: [cx, cy, w, h, conf, class_one_hot(4)] = 9 dims
        self.max_dets = max_dets
        in_dim = max_dets * 9
        self.net = nn.Sequential(
            nn.Linear(in_dim, 128), nn.ReLU(),
            nn.Linear(128, out_dim), nn.ReLU(),
        )

    def forward(self, det_tensor: torch.Tensor) -> torch.Tensor:
        """
        det_tensor: (B, max_dets, 9) — zero-padded detections.
        Returns: (B, out_dim)
        """
        B = det_tensor.shape[0]
        flat = det_tensor.view(B, -1)
        return self.net(flat)

    @staticmethod
    def encode_detections(det_frame, img_w: int = 640, img_h: int = 480, max_dets: int = 20) -> np.ndarray:
        """Convert a DetectionFrame to a (max_dets, 9) numpy array."""
        CLASS_TO_IDX = {0: 0, 2: 1, 5: 2, 7: 3}
        result = np.zeros((max_dets, 9), dtype=np.float32)
        for i, det in enumerate(det_frame.detections[:max_dets]):
            x1, y1, x2, y2 = det.bbox_xyxy
            cx = ((x1 + x2) / 2) / img_w
            cy = ((y1 + y2) / 2) / img_h
            w = (x2 - x1) / img_w
            h = (y2 - y1) / img_h
            one_hot = np.zeros(4)
            one_hot[CLASS_TO_IDX.get(det.class_id, 0)] = 1.0
            result[i] = [cx, cy, w, h, det.confidence, *one_hot]
        return result


class DepthEncoder(nn.Module):
    """Encode a depth map patch into a feature vector."""

    def __init__(self, out_dim: int = 64, patch_size: int = 32):
        super().__init__()
        self.patch_size = patch_size
        self.conv = nn.Sequential(
            nn.Conv2d(1, 16, 3, stride=2, padding=1), nn.ReLU(),
            nn.Conv2d(16, 32, 3, stride=2, padding=1), nn.ReLU(),
            nn.AdaptiveAvgPool2d((4, 4)),
            nn.Flatten(),
            nn.Linear(32 * 16, out_dim), nn.ReLU(),
        )

    def forward(self, depth_map: torch.Tensor) -> torch.Tensor:
        """depth_map: (B, 1, H, W) or (B, H, W) → (B, out_dim)"""
        if depth_map.dim() == 3:
            depth_map = depth_map.unsqueeze(1)
        resized = F.interpolate(depth_map, size=(self.patch_size, self.patch_size), mode="bilinear", align_corners=False)
        return self.conv(resized)


class LaneEncoder(nn.Module):
    """Encode lane info as a small feature vector."""

    def __init__(self, out_dim: int = 32):
        super().__init__()
        # inputs: [lane_error_norm, lane_detected, lane_width_norm]
        self.net = nn.Sequential(
            nn.Linear(3, 32), nn.ReLU(),
            nn.Linear(32, out_dim), nn.ReLU(),
        )

    def forward(self, lane_feat: torch.Tensor) -> torch.Tensor:
        """lane_feat: (B, 3)"""
        return self.net(lane_feat)


# ============================================================
# Fusion Head
# ============================================================

class LatentFusionHead(nn.Module):
    """
    g_ω: multimodal input → predicted latent state Zhat.
    Input dimensions:
        - visual (DINOv2): 768
        - YOLO encoding:    64
        - depth encoding:   64
        - lane encoding:    32
        - pcross:            1
        - ego speed:         1
        - yaw rate:          1
    Total: 931
    """

    VIS_DIM   = 768
    YOLO_DIM  = 64
    DEPTH_DIM = 64
    LANE_DIM  = 32
    SCALAR_DIM = 3    # pcross, v, yaw_rate

    def __init__(
        self,
        latent_dim: int = 10,
        hidden_dims: List[int] = (512, 256, 128),
        dropout: float = 0.1,
        noise_aware: bool = True,
    ):
        super().__init__()
        self.latent_dim = latent_dim
        self.noise_aware = noise_aware

        self.yolo_enc = YOLOEncoder(out_dim=self.YOLO_DIM)
        self.depth_enc = DepthEncoder(out_dim=self.DEPTH_DIM)
        self.lane_enc = LaneEncoder(out_dim=self.LANE_DIM)

        in_dim = (self.VIS_DIM + self.YOLO_DIM + self.DEPTH_DIM +
                  self.LANE_DIM + self.SCALAR_DIM)

        layers = []
        prev = in_dim
        for h in hidden_dims:
            layers += [nn.Linear(prev, h), nn.LayerNorm(h), nn.GELU(), nn.Dropout(dropout)]
            prev = h
        self.trunk = nn.Sequential(*layers)

        # Output head: mean + optional log-uncertainty
        self.mu_head = nn.Linear(prev, latent_dim)
        if noise_aware:
            self.log_eta_head = nn.Linear(prev, latent_dim)

        # Separate activation for prob vs regression dims
        self._prob_idx = [0, 1, 2, 3, 5]    # ol, oc, or, pcoll, pcross

    def forward(
        self,
        h_vis: torch.Tensor,         # (B, 768)
        det_tensor: torch.Tensor,    # (B, 20, 9)
        depth_map: torch.Tensor,     # (B, H, W)
        lane_feat: torch.Tensor,     # (B, 3)
        scalars: torch.Tensor,       # (B, 3) — pcross, v, yaw_rate
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
        """
        Returns:
            z_hat: (B, latent_dim)
            log_eta: (B, latent_dim) uncertainty per dimension, or None
        """
        y = self.yolo_enc(det_tensor)
        d = self.depth_enc(depth_map)
        l = self.lane_enc(lane_feat)

        fused = torch.cat([h_vis, y, d, l, scalars], dim=-1)
        feat = self.trunk(fused)
        mu = self.mu_head(feat)

        # Apply sigmoid to probability dimensions
        z_hat = mu.clone()
        prob_mask = torch.zeros(self.latent_dim, device=mu.device, dtype=torch.bool)
        prob_mask[self._prob_idx] = True
        z_hat[:, prob_mask] = torch.sigmoid(mu[:, prob_mask])

        log_eta = self.log_eta_head(feat) if self.noise_aware else None
        return z_hat, log_eta


# ============================================================
# Fusion Training Losses
# ============================================================

def latent_loss(
    z_hat: torch.Tensor,
    z_true: torch.Tensor,
    log_eta: Optional[torch.Tensor] = None,
    prob_indices: List[int] = (0, 1, 2, 3, 5),
) -> torch.Tensor:
    """
    Per-dimension loss:
    - BCE for probability dimensions
    - MSE for regression dimensions
    If log_eta provided, apply noise-aware weighting: w = exp(-η)
    """
    B, D = z_hat.shape
    losses = torch.zeros(B, D, device=z_hat.device)

    for i in range(D):
        if i in prob_indices:
            losses[:, i] = F.binary_cross_entropy(
                z_hat[:, i].clamp(1e-6, 1 - 1e-6),
                z_true[:, i],
                reduction="none",
            )
        else:
            losses[:, i] = F.mse_loss(z_hat[:, i], z_true[:, i], reduction="none")

    if log_eta is not None:
        # Noise-aware: w = exp(-η), loss = w * ℓ + η (regularisation)
        eta = log_eta.exp()
        w = (-log_eta).exp()
        weighted = (w * losses + log_eta).mean()
        return weighted
    else:
        return losses.mean()


class FusionTrainer:
    """Full training loop for the latent fusion head."""

    def __init__(self, model: LatentFusionHead, cfg: dict, device: str = "cuda"):
        self.model = model.to(device)
        self.cfg = cfg
        self.device = device
        self.optimizer = torch.optim.AdamW(
            model.parameters(),
            lr=cfg.get("lr", 1e-3),
            weight_decay=cfg.get("weight_decay", 1e-4),
        )
        self.lambda_z = cfg.get("lambda_z", 1.0)
        self.prob_idx = [0, 1, 2, 3, 5]

    def train_epoch(self, loader) -> float:
        self.model.train()
        total_loss = 0.0
        for batch in loader:
            h_vis = batch["h_vis"].to(self.device)
            det   = batch["det"].to(self.device)
            depth = batch["depth"].to(self.device)
            lane  = batch["lane"].to(self.device)
            scalars = batch["scalars"].to(self.device)
            z_true = batch["z_true"].to(self.device)

            z_hat, log_eta = self.model(h_vis, det, depth, lane, scalars)
            loss = self.lambda_z * latent_loss(z_hat, z_true, log_eta, self.prob_idx)

            self.optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
            self.optimizer.step()
            total_loss += loss.item()

        return total_loss / len(loader)

    def evaluate(self, loader) -> dict:
        """Compute per-dimension MAE, RMSE, and AUC for prob dimensions."""
        from sklearn.metrics import roc_auc_score
        self.model.eval()
        all_pred, all_true = [], []
        with torch.no_grad():
            for batch in loader:
                h_vis   = batch["h_vis"].to(self.device)
                det     = batch["det"].to(self.device)
                depth   = batch["depth"].to(self.device)
                lane    = batch["lane"].to(self.device)
                scalars = batch["scalars"].to(self.device)
                z_hat, _ = self.model(h_vis, det, depth, lane, scalars)
                all_pred.append(z_hat.cpu().numpy())
                all_true.append(batch["z_true"].numpy())

        pred = np.concatenate(all_pred)
        true = np.concatenate(all_true)
        names = ["ol","oc","or","pcoll","TTC","pcross","dped","v","elane","yaw_rate"]
        metrics = {}
        for i, n in enumerate(names):
            mae = float(np.mean(np.abs(pred[:, i] - true[:, i])))
            rmse = float(np.sqrt(np.mean((pred[:, i] - true[:, i])**2)))
            metrics[f"{n}_mae"] = mae
            metrics[f"{n}_rmse"] = rmse
            if i in self.prob_idx:
                try:
                    auc = roc_auc_score((true[:, i] > 0.5).astype(int), pred[:, i])
                    metrics[f"{n}_auc"] = float(auc)
                except Exception:
                    pass
        return metrics
