"""
Final Evaluation — runs all baselines across all 5 scene types.
Run: python scripts/run_final_eval.py
"""
import sys, yaml, json
import numpy as np
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))


def random_policy(obs):
    """Placeholder policy for testing the eval pipeline."""
    return np.array([
        np.random.uniform(-0.1, 0.1),   # steer
        np.random.uniform(0.3, 0.6),    # throttle
        0.0,                             # brake
    ], dtype=np.float32)


def constant_policy(throttle=0.4):
    def policy(obs):
        # Slow down if high occlusion or pcoll
        oc = float(obs[1])
        pcoll = float(obs[3])
        brake = float(np.clip(pcoll * 0.8 + oc * 0.3, 0, 1))
        thr = float(np.clip(throttle - brake * 0.5, 0, 1))
        steer = float(-obs[8] * 0.5)   # lane-following
        return np.array([steer, thr, brake], dtype=np.float32)
    return policy


def main():
    with open("config/config.yaml") as f:
        cfg = yaml.safe_load(f)

    from rl.env import CARLADrivingEnv
    from latent.labels import LatentLabelComputer
    from eval.evaluator import Evaluator

    def env_factory(scene_type):
        env = CARLADrivingEnv(cfg=cfg, mode="true_z")
        env.set_perception_modules(
            label_computer=LatentLabelComputer(),
        )
        return env

    evaluator = Evaluator(cfg=cfg, log_dir="logs/eval")

    # ----- Baseline 1: Nominal rule-based controller -----
    print("\n[Final Eval] Running baseline: nominal controller")
    nominal_results = evaluator.evaluate_policy(
        policy=constant_policy(throttle=0.4),
        env_factory=env_factory,
        n_episodes=cfg["eval"]["n_episodes"],
    )

    # ----- Baseline 2: Trained PPO on true Z -----
    ppo_results = {}
    ppo_path = Path("checkpoints/7_ppo/final_model.zip")
    if ppo_path.exists():
        print("\n[Final Eval] Running baseline: PPO on true Z")
        from stable_baselines3 import PPO
        from stable_baselines3.common.vec_env import DummyVecEnv, VecNormalize
        from stable_baselines3.common.monitor import Monitor

        vec_env = DummyVecEnv([lambda: Monitor(env_factory("easy_clear"))])
        vec_env = VecNormalize(vec_env, norm_obs=True, norm_reward=False, training=False)
        ppo_model = PPO.load(str(ppo_path), env=vec_env)
        ppo_results = evaluator.evaluate_policy(
            policy=lambda obs: ppo_model.predict(obs[np.newaxis], deterministic=True)[0][0],
            env_factory=env_factory,
            n_episodes=cfg["eval"]["n_episodes"],
        )

    # ----- Compare -----
    baselines = {"Nominal Controller": nominal_results}
    if ppo_results:
        baselines["PPO (true Z)"] = ppo_results

    if len(baselines) > 1:
        evaluator.compare_baselines(baselines, save_prefix="baseline_comparison")

    print("\n[Final Eval] Complete. Results in logs/eval/")


if __name__ == "__main__":
    import os
    os.chdir(Path(__file__).parent.parent)
    main()
