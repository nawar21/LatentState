"""
Stage 10 — Switch from True Z to Predicted Zhat
Evaluates the performance gap between oracle and predicted latent state.
Run: python scripts/stage10_zhat.py --ppo_checkpoint checkpoints/8_cvar/final_model
"""
import sys, argparse, yaml
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import numpy as np


def main(args):
    with open("config/config.yaml") as f:
        cfg = yaml.safe_load(f)

    import torch
    device = "cuda" if torch.cuda.is_available() else "cpu"

    # Load SSL backbone
    from perception.backbone import DINOv2Backbone
    backbone = DINOv2Backbone(
        model_name=cfg["perception"]["backbone"]["model"],
        pretrained=False,
        freeze=True,
        proj_dim=cfg["ssl"]["proj_dim"],
    )
    ssl_ckpt = Path("checkpoints/ssl/ssl_backbone.pth")
    if ssl_ckpt.exists():
        ckpt = torch.load(ssl_ckpt, map_location=device)
        backbone.load_state_dict(ckpt["model_state_dict"])
        print(f"[Stage 10] Loaded SSL backbone from {ssl_ckpt}")

    # Load fusion head
    from latent.fusion import LatentFusionHead
    fusion = LatentFusionHead(
        latent_dim=10,
        hidden_dims=cfg["fusion"]["hidden_dims"],
        dropout=cfg["fusion"]["dropout"],
    )
    fusion_ckpt = Path("checkpoints/fusion/fusion_head.pth")
    if fusion_ckpt.exists():
        ckpt = torch.load(fusion_ckpt, map_location=device)
        fusion.load_state_dict(ckpt["model_state_dict"])
        print(f"[Stage 10] Loaded fusion head from {fusion_ckpt}")

    # Create predicted-Z env
    from rl.env import CARLADrivingEnv
    from latent.labels import LatentLabelComputer
    from perception.lane import LaneDetector

    def make_zhat_env():
        env = CARLADrivingEnv(cfg=cfg, mode="predicted_z")
        env.set_perception_modules(
            backbone=backbone.to(device),
            fusion_head=fusion.to(device),
            label_computer=LatentLabelComputer(),
            lane_detector=LaneDetector(),
        )
        return env

    # Load trained policy
    from stable_baselines3 import PPO
    from stable_baselines3.common.vec_env import DummyVecEnv, VecNormalize
    from stable_baselines3.common.monitor import Monitor

    vec_env = DummyVecEnv([lambda: Monitor(make_zhat_env())])
    vec_env = VecNormalize(vec_env, norm_obs=True, norm_reward=False, training=False)

    model = PPO.load(args.ppo_checkpoint, env=vec_env)
    print(f"[Stage 10] Loaded policy from {args.ppo_checkpoint}")

    # Quick evaluation
    print("[Stage 10] Evaluating predicted-Z policy...")
    returns, collisions = [], []
    for ep in range(args.n_episodes):
        obs = vec_env.reset()
        total_r = 0.0
        coll = False
        for _ in range(1000):
            action, _ = model.predict(obs, deterministic=True)
            obs, r, done, info = vec_env.step(action)
            total_r += float(r[0])
            if info[0].get("collision"):
                coll = True
            if done[0]:
                break
        returns.append(total_r)
        collisions.append(float(coll))
        print(f"  Episode {ep+1}: R={total_r:.2f} | Coll={coll}")

    print(f"\n[Stage 10] Results (predicted Zhat):")
    print(f"  Mean return:    {np.mean(returns):.3f}")
    print(f"  Collision rate: {np.mean(collisions):.3f}")
    print(f"  CVaR(5%):       {np.sort(returns)[:max(1, int(len(returns)*0.05))].mean():.3f}")
    print("Next: python scripts/stage11_llm.py")


if __name__ == "__main__":
    import os
    os.chdir(Path(__file__).parent.parent)
    parser = argparse.ArgumentParser()
    parser.add_argument("--ppo_checkpoint", default="checkpoints/8_cvar/final_model")
    parser.add_argument("--n_episodes", type=int, default=20)
    main(parser.parse_args())
