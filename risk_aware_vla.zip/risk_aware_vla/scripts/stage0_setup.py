"""
Stage 0 — Environment Setup & CARLA Verification
Run: python scripts/stage0_setup.py
"""
import os, sys, yaml, json, argparse
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))


def check_carla():
    try:
        import carla
        print("✓ CARLA Python API found")
        return True
    except ImportError:
        print("✗ CARLA Python API not found. Install from: https://carla.org/")
        print("  Or run: pip install carla==0.9.15")
        return False


def check_dependencies():
    checks = {
        "torch": "import torch; print(f'✓ PyTorch {torch.__version__}')",
        "torchvision": "import torchvision; print(f'✓ torchvision {torchvision.__version__}')",
        "timm": "import timm; print(f'✓ timm {timm.__version__}')",
        "ultralytics": "from ultralytics import YOLO; print('✓ ultralytics (YOLOv8)')",
        "transformers": "import transformers; print(f'✓ transformers {transformers.__version__}')",
        "stable_baselines3": "import stable_baselines3; print(f'✓ SB3 {stable_baselines3.__version__}')",
        "gymnasium": "import gymnasium; print(f'✓ gymnasium {gymnasium.__version__}')",
        "albumentations": "import albumentations; print(f'✓ albumentations {albumentations.__version__}')",
        "cv2": "import cv2; print(f'✓ OpenCV {cv2.__version__}')",
    }
    for name, check_code in checks.items():
        try:
            exec(check_code)
        except Exception as e:
            print(f"✗ {name}: {e}")


def create_directory_structure():
    dirs = [
        "data/pie/clips", "data/pie",
        "data/jaad/clips", "data/jaad",
        "data/carla/frames", "data/carla/logs",
        "checkpoints/ssl", "checkpoints/ppo",
        "checkpoints/ppo/best", "checkpoints/fusion",
        "logs/ssl", "logs/ppo", "logs/eval",
        "notebooks",
    ]
    for d in dirs:
        Path(d).mkdir(parents=True, exist_ok=True)
    print("✓ Directory structure created")


def create_carla_logger():
    """Writes a CARLA data collection script."""
    script = '''"""
CARLA Data Logger — collect frames + ego state for SSL and latent label generation.
Run CARLA server first: ./CarlaUE4.sh -RenderOffScreen
Then: python scripts/carla_logger.py
"""
import sys, os, time, json, csv
import numpy as np
import cv2
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

OUTPUT_DIR = Path("data/carla")
FRAMES_DIR = OUTPUT_DIR / "frames"
FRAMES_DIR.mkdir(parents=True, exist_ok=True)

try:
    import carla
except ImportError:
    print("CARLA not available. Exiting.")
    sys.exit(0)

client = carla.Client("localhost", 2000)
client.set_timeout(20.0)
world = client.get_world()

settings = world.get_settings()
settings.synchronous_mode = True
settings.fixed_delta_seconds = 0.05
world.apply_settings(settings)

bp_lib = world.get_blueprint_library()
vehicle_bp = bp_lib.filter("vehicle.lincoln.mkz_2020")[0]
spawn_pts = world.get_map().get_spawn_points()

vehicle = world.spawn_actor(vehicle_bp, spawn_pts[0])
vehicle.set_autopilot(True)

cam_bp = bp_lib.find("sensor.camera.rgb")
cam_bp.set_attribute("image_size_x", "640")
cam_bp.set_attribute("image_size_y", "480")
cam_bp.set_attribute("fov", "90")
camera = world.spawn_actor(cam_bp, carla.Transform(carla.Location(x=1.5, z=2.4)), attach_to=vehicle)

log_data = []
frame_count = 0
current_frame = None

def on_camera(image):
    global current_frame
    arr = np.frombuffer(image.raw_data, dtype=np.uint8).reshape(image.height, image.width, 4)
    current_frame = arr[:, :, :3]

camera.listen(on_camera)

print("Collecting data. Press Ctrl+C to stop.")
try:
    while frame_count < 5000:
        world.tick()
        if current_frame is None:
            continue

        vel = vehicle.get_velocity()
        speed = (vel.x**2 + vel.y**2 + vel.z**2) ** 0.5
        ang_vel = vehicle.get_angular_velocity()
        tr = vehicle.get_transform()

        frame_path = FRAMES_DIR / f"{frame_count:06d}.jpg"
        cv2.imwrite(str(frame_path), current_frame)

        log_data.append({
            "frame": frame_count,
            "speed": speed,
            "yaw_rate": ang_vel.z,
            "x": tr.location.x,
            "y": tr.location.y,
            "heading": tr.rotation.yaw,
            "timestamp": time.time(),
        })
        frame_count += 1
        if frame_count % 100 == 0:
            print(f"  Collected {frame_count} frames")

except KeyboardInterrupt:
    pass
finally:
    with open(OUTPUT_DIR / "ego_log.json", "w") as f:
        json.dump(log_data, f, indent=2)
    camera.destroy()
    vehicle.destroy()
    settings.synchronous_mode = False
    world.apply_settings(settings)
    print(f"Done. Saved {frame_count} frames and ego log.")
'''
    with open("scripts/carla_logger.py", "w") as f:
        f.write(script)
    print("✓ scripts/carla_logger.py written")


def main():
    print("=" * 60)
    print("  Risk-Aware VLA — Stage 0: Environment Setup")
    print("=" * 60)

    create_directory_structure()
    check_dependencies()
    carla_ok = check_carla()
    create_carla_logger()

    print("\n" + "=" * 60)
    print("Stage 0 complete.")
    if not carla_ok:
        print("⚠ CARLA is not installed. Install it to proceed with data collection.")
    print("Next step: python scripts/stage1_pie_pipeline.py")


if __name__ == "__main__":
    os.chdir(Path(__file__).parent.parent)
    main()
