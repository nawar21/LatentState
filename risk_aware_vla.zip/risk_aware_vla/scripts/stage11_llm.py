"""
Stage 11 — LLM Explanation Branch
Tests and benchmarks the frozen LLM explainer.
Run: python scripts/stage11_llm.py [--model mistralai/Mistral-7B-Instruct-v0.2] [--fallback]
"""
import sys, argparse, yaml, json
import numpy as np
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))


def generate_test_scenarios():
    """Create a set of diverse latent vectors and expected behaviors."""
    return [
        {
            "name": "occluded_intersection",
            "z": np.array([0.2, 0.9, 0.3, 0.75, 0.15, 0.4, 0.3, 0.3, 0.05, 0.1]),
            "action": np.array([-0.02, 0.0, 0.65]),
            "expected_dominant": "OccCenter",
        },
        {
            "name": "pedestrian_about_to_cross",
            "z": np.array([0.1, 0.3, 0.1, 0.62, 0.3, 0.85, 0.25, 0.25, 0.02, 0.05]),
            "action": np.array([0.01, 0.0, 0.55]),
            "expected_dominant": "PedCrossProb",
        },
        {
            "name": "low_ttc",
            "z": np.array([0.1, 0.2, 0.1, 0.70, 0.08, 0.2, 0.5, 0.6, 0.03, 0.1]),
            "action": np.array([0.0, 0.0, 0.80]),
            "expected_dominant": "TTC",
        },
        {
            "name": "lane_departure",
            "z": np.array([0.05, 0.1, 0.05, 0.1, 0.9, 0.05, 0.8, 0.4, -0.65, 0.3]),
            "action": np.array([0.45, 0.3, 0.0]),
            "expected_dominant": "LaneError",
        },
        {
            "name": "clear_road",
            "z": np.array([0.05, 0.05, 0.05, 0.05, 0.95, 0.05, 0.9, 0.55, 0.02, 0.02]),
            "action": np.array([0.0, 0.7, 0.0]),
            "expected_dominant": "Speed",
        },
    ]


def main(args):
    with open("config/config.yaml") as f:
        cfg = yaml.safe_load(f)

    llm_cfg = cfg["llm"]
    from llm.explainer import LLMExplainer

    explainer = LLMExplainer(
        model_name=args.model or llm_cfg["model"],
        max_new_tokens=llm_cfg["max_new_tokens"],
        temperature=llm_cfg["temperature"],
        device=cfg["project"]["device"],
        fallback_only=args.fallback,
    )

    scenarios = generate_test_scenarios()
    results = []

    print("\n" + "=" * 70)
    print("  Stage 11 — LLM Explanation Evaluation")
    print("=" * 70)

    for sc in scenarios:
        exp = explainer.explain(sc["z"], sc["action"], force=True)
        dominant_hit = sc["expected_dominant"].lower() in exp.dominant_factor.lower()

        print(f"\nScenario: {sc['name']}")
        print(f"  Expected dominant: {sc['expected_dominant']}")
        print(f"  Detected dominant: {exp.dominant_factor}")
        print(f"  Explanation:       {exp.text}")
        print(f"  Latency:           {exp.latency_ms:.1f} ms")
        print(f"  Dominant match:    {'✓' if dominant_hit else '✗'}")

        results.append({
            "scenario": sc["name"],
            "explanation": exp.text,
            "dominant_factor": exp.dominant_factor,
            "expected_dominant": sc["expected_dominant"],
            "dominant_match": dominant_hit,
            "latency_ms": exp.latency_ms,
        })

    # Batch evaluation metrics
    z_batch = np.array([s["z"] for s in scenarios])
    a_batch = np.array([s["action"] for s in scenarios])
    metrics = explainer.batch_evaluate(z_batch, a_batch)

    print("\n--- Aggregate Metrics ---")
    for k, v in metrics.items():
        print(f"  {k}: {v:.4f}" if isinstance(v, float) else f"  {k}: {v}")

    # Save
    Path("logs/eval").mkdir(parents=True, exist_ok=True)
    out = {"results": results, "metrics": metrics}
    with open("logs/eval/stage11_llm_results.json", "w") as f:
        json.dump(out, f, indent=2)
    print("\n[Stage 11] Results saved → logs/eval/stage11_llm_results.json")
    print("Next: python scripts/run_final_eval.py")


if __name__ == "__main__":
    import os
    os.chdir(Path(__file__).parent.parent)
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default=None)
    parser.add_argument("--fallback", action="store_true", help="Use rule-based fallback only")
    main(parser.parse_args())
