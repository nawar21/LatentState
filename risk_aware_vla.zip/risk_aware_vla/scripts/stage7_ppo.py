"""
Stage 7 — Train PPO on True Latent State
Stage 8 — Add CVaR Tail-Risk Training (--cvar flag)
Run: python scripts/stage7_ppo.py [--cvar] [--timesteps 1000000]
"""
import sys, argparse
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import yaml


def make_env(cfg, mode="true_z", scene_type="easy_clear"):
    """Factory for one CARLA env instance."""
    from rl.env import CARLADrivingEnv
    from latent.labels import LatentLabelComputer
    from perception.lane import LaneDetector
    from perception.pedestrian_intention import PedestrianIntentionInference

    env = CARLADrivingEnv(cfg=cfg, mode=mode)
    env.set_perception_modules(
        label_computer=LatentLabelComputer(**cfg["latent"]["pcoll_weights"]),
        lane_detector=LaneDetector(),
        pip=PedestrianIntentionInference(
            model_path=cfg["perception"]["pip"].get("model_path"),
            device=cfg.get("project", {}).get("device", "cpu"),
        ),
    )
    return env


def main(args):
    with open("config/config.yaml") as f:
        cfg = yaml.safe_load(f)

    use_cvar = args.cvar
    stage = "8_cvar" if use_cvar else "7_ppo"
    print(f"[Stage {stage}] Starting {'CVaR-' if use_cvar else ''}PPO training")

    from rl.ppo import PPOTrainer

    trainer = PPOTrainer(
        env_factory=lambda: make_env(cfg, mode="true_z"),
        cfg=cfg,
        use_cvar=use_cvar,
        log_dir=f"logs/{stage}",
        checkpoint_dir=f"checkpoints/{stage}",
    )

    trainer.train(
        total_timesteps=args.timesteps or cfg["ppo"]["total_timesteps"],
        eval_env_factory=lambda: make_env(cfg, mode="true_z"),
    )
    print(f"[Stage {stage}] Done.")
    print("Next: python scripts/stage10_zhat.py")


if __name__ == "__main__":
    import os
    os.chdir(Path(__file__).parent.parent)
    parser = argparse.ArgumentParser()
    parser.add_argument("--cvar", action="store_true", help="Enable CVaR training (Stage 8)")
    parser.add_argument("--timesteps", type=int, default=None)
    main(parser.parse_args())
