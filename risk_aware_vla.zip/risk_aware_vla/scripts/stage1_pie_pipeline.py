"""Stage 1 — PIE Pedestrian Pipeline"""
import sys, yaml, argparse, torch
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

def main(args):
    with open("config/config.yaml") as f:
        cfg = yaml.safe_load(f)
    from perception.pedestrian_intention import PedestrianClipDataset, PIPModel
    pip_cfg = cfg["perception"]["pip"]
    device = "cuda" if torch.cuda.is_available() else "cpu"
    train_ds = PedestrianClipDataset("data/pie", split="train", clip_len=pip_cfg["clip_len"])
    print(f"[Stage 1] PIE train samples: {len(train_ds)}")
    if len(train_ds) == 0:
        print("  No PIE data. Download: https://data.nvision2.eecs.yorku.ca/PIE_dataset/")
        print("  Saving untrained PIP model as checkpoint...")
        model = PIPModel(clip_len=pip_cfg["clip_len"])
        Path(pip_cfg["model_path"]).parent.mkdir(parents=True, exist_ok=True)
        torch.save({"model_state_dict": model.state_dict(), "epoch": 0}, pip_cfg["model_path"])
        return
    model = PIPModel(clip_len=pip_cfg["clip_len"]).to(device)
    from torch.utils.data import DataLoader
    loader = DataLoader(train_ds, batch_size=16, shuffle=True)
    opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    crit = torch.nn.BCELoss()
    for ep in range(args.epochs):
        for b in loader:
            p = model(b["frames"].to(device), b["ego_speed"].to(device))
            loss = crit(p, b["label"].to(device))
            opt.zero_grad(); loss.backward(); opt.step()
        print(f"  Epoch {ep+1}/{args.epochs}")
    torch.save({"model_state_dict": model.state_dict()}, pip_cfg["model_path"])
    print(f"[Stage 1] Done. Model saved to {pip_cfg['model_path']}")

if __name__ == "__main__":
    import os; os.chdir(Path(__file__).parent.parent)
    parser = argparse.ArgumentParser()
    parser.add_argument("--epochs", type=int, default=30)
    main(parser.parse_args())
