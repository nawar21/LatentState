"""Stage 5 — Train latent fusion head."""
import sys, yaml, torch
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

def main():
    with open("config/config.yaml") as f:
        cfg = yaml.safe_load(f)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    from latent.fusion import LatentFusionHead
    fc = cfg["fusion"]
    model = LatentFusionHead(latent_dim=10, hidden_dims=fc["hidden_dims"],
                              dropout=fc["dropout"], noise_aware=fc["noise_aware"])
    print(f"[Stage 5] Fusion head: {sum(p.numel() for p in model.parameters()):,} params")
    # Architecture check
    h = torch.zeros(2, 768); det = torch.zeros(2, 20, 9)
    depth = torch.zeros(2, 480, 640); lane = torch.zeros(2, 3); sc = torch.zeros(2, 3)
    z_hat, log_eta = model(h, det, depth, lane, sc)
    print(f"  Forward pass: z_hat={z_hat.shape} ✓")
    print("[Stage 5] To train: provide data/carla/latent_labels.npy from CARLA rollouts")

if __name__ == "__main__":
    import os; os.chdir(Path(__file__).parent.parent)
    main()
