"""
Stage 4 — Self-Supervised Visual Backbone Adaptation
Run: python scripts/stage4_ssl.py [--frames_dir data/carla/frames] [--epochs 50]
"""
import sys, argparse
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import yaml
import torch


def main(args):
    with open("config/config.yaml") as f:
        cfg = yaml.safe_load(f)

    ssl_cfg = cfg["ssl"]
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"[Stage 4] SSL training on device: {device}")

    # 1. Build backbone with projection head
    from perception.backbone import DINOv2Backbone
    backbone = DINOv2Backbone(
        model_name=cfg["perception"]["backbone"]["model"],
        pretrained=cfg["perception"]["backbone"]["pretrained"],
        freeze=True,
        proj_dim=ssl_cfg["proj_dim"],
    )

    # 2. Build dataset
    from ssl.ssl_trainer import UnlabeledFrameDataset, build_ssl_augmentation
    aug = build_ssl_augmentation(ssl_cfg["augmentations"])
    dataset = UnlabeledFrameDataset(frame_dir=args.frames_dir, augmentation=aug)

    if len(dataset) == 0:
        print(f"[Stage 4] No frames found in {args.frames_dir}.")
        print("  Run scripts/carla_logger.py first to collect frames.")
        print("  Or use PIE/JAAD frames: data/pie/clips/")
        return

    # 3. Train
    from ssl.ssl_trainer import SSLTrainer
    trainer = SSLTrainer(
        backbone=backbone,
        cfg=ssl_cfg,
        device=device,
        log_dir="logs/ssl",
    )
    history = trainer.train(
        dataset=dataset,
        epochs=args.epochs or ssl_cfg["epochs"],
        save_path="checkpoints/ssl/ssl_backbone.pth",
    )

    # 4. Plot loss
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots()
    ax.plot(history["loss"], label="Total")
    ax.plot(history["inv"], label="Invariance")
    ax.plot(history["var"], label="Variance")
    ax.plot(history["cov"], label="Covariance")
    ax.set_xlabel("Epoch"); ax.set_ylabel("Loss")
    ax.legend(); ax.set_title("SSL Training Loss")
    plt.savefig("logs/ssl/ssl_loss.png", dpi=120)
    plt.close()
    print("[Stage 4] Done. Checkpoint: checkpoints/ssl/ssl_backbone.pth")
    print("Next: python scripts/stage5_fusion.py")


if __name__ == "__main__":
    import os
    os.chdir(Path(__file__).parent.parent)
    parser = argparse.ArgumentParser()
    parser.add_argument("--frames_dir", default="data/carla/frames")
    parser.add_argument("--epochs", type=int, default=None)
    main(parser.parse_args())
