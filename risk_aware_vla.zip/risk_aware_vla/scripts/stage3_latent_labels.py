"""Stage 3 — Validate latent label generation from CARLA state."""
import sys, yaml, numpy as np
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

def main():
    with open("config/config.yaml") as f:
        cfg = yaml.safe_load(f)
    from latent.labels import LatentLabelComputer, CarlaState
    computer = LatentLabelComputer(**cfg["latent"]["pcoll_weights"])
    # Occluded pedestrian test
    s = CarlaState(ego_velocity=5.0, ego_yaw_rate=0.0, ego_location=np.zeros(3), ego_heading=0.0,
                   pedestrians=[{"id":1,"location":[8.,0.,0.],"velocity":[0.,0.],"occluded":True}])
    lbl = computer.compute(s, pcross=0.2, lane_error_norm=0.0)
    print(f"[Stage 3] Occluded ped: oc={lbl.oc:.3f} pcoll={lbl.pcoll:.3f}  ← should be elevated")
    print(f"[Stage 3] Label vector: {np.round(lbl.to_array(), 3)}")
    assert lbl.oc > 0.3, "Occlusion score not elevated!"
    print("[Stage 3] ✓ Sanity checks passed")

if __name__ == "__main__":
    import os; os.chdir(Path(__file__).parent.parent)
    main()
