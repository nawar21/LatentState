"""
Stage 11 — Frozen LLM Explanation Branch
Generates natural language explanations from the latent risk vector.
Runs at ~1Hz in parallel with the 20Hz control loop.
"""
from __future__ import annotations
import numpy as np
from typing import Optional, Dict, List
from dataclasses import dataclass
import time

try:
    import torch
    from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline
    HF_AVAILABLE = True
except ImportError:
    HF_AVAILABLE = False


# ============================================================
# Prompt Builder
# ============================================================

SYSTEM_PROMPT = """You are the reasoning module of an autonomous driving system.
You receive the current risk state of the vehicle and the action it took.
Explain in ONE concise sentence why the vehicle took this action, focusing on the dominant risk factor.
Be specific. Do not speculate beyond what the data shows."""

def build_prompt(z: np.ndarray, action: np.ndarray, names: Optional[List[str]] = None) -> str:
    """Build a structured prompt from the latent vector and action."""
    if names is None:
        names = ["OccLeft", "OccCenter", "OccRight", "CollisionProb",
                 "TTC", "PedCrossProb", "PedDistance", "Speed",
                 "LaneError", "YawRate"]

    # Format latent state
    lines = []
    for name, val in zip(names, z):
        lines.append(f"{name} = {val:.3f}")

    steer, throttle, brake = action[0], action[1], action[2]
    action_str = f"Steer={steer:+.2f}, Throttle={throttle:.2f}, Brake={brake:.2f}"

    prompt = (
        "Current Risk State:\n"
        + "\n".join(lines)
        + f"\n\nAction Taken: {action_str}\n\n"
        + "Explain in one sentence why the vehicle took this action:"
    )
    return prompt


# ============================================================
# Explanation Generator
# ============================================================

@dataclass
class Explanation:
    text: str
    latency_ms: float
    timestamp: float
    dominant_factor: str


def find_dominant_factor(z: np.ndarray) -> str:
    """Heuristic: identify the most salient risk factor."""
    names = ["OccLeft", "OccCenter", "OccRight", "CollisionProb",
             "TTC", "PedCrossProb", "PedDist", "Speed", "LaneError", "YawRate"]
    # Risk-weighted importance
    weights = np.array([1.0, 1.5, 1.0, 2.0, 1.8, 1.7, 1.3, 0.5, 0.8, 0.4])
    scores = z * weights
    idx = int(np.argmax(np.abs(scores)))
    return names[idx]


class LLMExplainer:
    """
    Frozen LLM explanation branch.
    - Runs at 1Hz (every N control steps)
    - Uses a small instruction-tuned model
    - Falls back to a rule-based explainer if LLM unavailable
    """

    def __init__(
        self,
        model_name: str = "mistralai/Mistral-7B-Instruct-v0.2",
        max_new_tokens: int = 128,
        temperature: float = 0.1,
        device: str = "cuda",
        freq_hz: int = 1,
        fallback_only: bool = False,
    ):
        self.max_tokens = max_new_tokens
        self.temperature = temperature
        self.freq_hz = freq_hz
        self._pipe = None
        self._step = 0

        if not fallback_only and HF_AVAILABLE:
            try:
                print(f"[LLMExplainer] Loading {model_name}...")
                self._pipe = pipeline(
                    "text-generation",
                    model=model_name,
                    device_map="auto" if device == "cuda" else device,
                    torch_dtype=torch.float16 if device == "cuda" else torch.float32,
                    max_new_tokens=max_new_tokens,
                    temperature=temperature,
                    do_sample=False,
                )
                print("[LLMExplainer] Model loaded.")
            except Exception as e:
                print(f"[LLMExplainer] Could not load {model_name}: {e} — using rule-based fallback.")

    # ------------------------------------------------------------------
    def explain(
        self,
        z: np.ndarray,
        action: np.ndarray,
        force: bool = False,
    ) -> Optional[Explanation]:
        """
        Generate an explanation. Returns None if not on a freq boundary.
        Args:
            z:      (10,) latent state
            action: (3,) [steer, throttle, brake]
            force:  if True, always generate (ignore freq)
        """
        self._step += 1
        if not force and (self._step % self.freq_hz != 0):
            return None

        t0 = time.time()
        dominant = find_dominant_factor(z)

        if self._pipe is not None:
            text = self._llm_explain(z, action)
        else:
            text = self._rule_explain(z, action, dominant)

        latency = (time.time() - t0) * 1000
        return Explanation(
            text=text,
            latency_ms=latency,
            timestamp=time.time(),
            dominant_factor=dominant,
        )

    def _llm_explain(self, z: np.ndarray, action: np.ndarray) -> str:
        prompt = build_prompt(z, action)
        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ]
        result = self._pipe(messages)
        return result[0]["generated_text"][-1]["content"].strip()

    def _rule_explain(self, z: np.ndarray, action: np.ndarray, dominant: str) -> str:
        """Template-based fallback explainer."""
        _, _, _, pcoll, ttc, pcross, dped, v, elane, _ = z
        _, throttle, brake = action

        if pcoll > 0.7:
            return (f"Braking due to high collision probability ({pcoll:.2f}) "
                    f"with TTC={ttc:.2f} and pedestrian at {dped:.2f} relative distance.")
        if pcross > 0.6:
            return (f"Decelerating because a pedestrian is likely crossing (p={pcross:.2f}) "
                    f"at {dped:.2f} relative distance.")
        if z[1] > 0.6:   # high center occlusion
            return (f"Slowing down to peek into occluded region (occlusion={z[1]:.2f}) "
                    f"to resolve uncertainty before proceeding.")
        if abs(elane) > 0.4:
            return (f"Steering to correct lane deviation (error={elane:+.2f}).")
        if brake > 0.3:
            return f"Braking due to elevated {dominant} ({z[list(['OccLeft','OccCenter','OccRight','CollisionProb','TTC','PedCrossProb','PedDist','Speed','LaneError','YawRate']).index(dominant)]:.2f})."
        return f"Maintaining normal driving; dominant factor is {dominant}."

    # ------------------------------------------------------------------
    def batch_evaluate(
        self,
        z_batch: np.ndarray,
        action_batch: np.ndarray,
        ground_truth_reasons: Optional[List[str]] = None,
    ) -> Dict:
        """
        Evaluate explanation quality over a batch.
        Returns: correctness, consistency, hallucination_rate, avg_latency
        """
        explanations = []
        latencies = []
        for z, a in zip(z_batch, action_batch):
            exp = self.explain(z, a, force=True)
            explanations.append(exp.text)
            latencies.append(exp.latency_ms)

        # Consistency: std of explanation length as a proxy
        lengths = [len(e.split()) for e in explanations]
        consistency = 1.0 - (np.std(lengths) / (np.mean(lengths) + 1e-6))

        # Hallucination proxy: check if explanation mentions the dominant factor
        hallucination_count = 0
        for i, (z, exp_text) in enumerate(zip(z_batch, explanations)):
            dominant = find_dominant_factor(z)
            # Simple keyword check
            dominant_keywords = dominant.lower().replace("occ", "occlus").split()
            if not any(kw in exp_text.lower() for kw in dominant_keywords):
                hallucination_count += 1

        return {
            "n_samples": len(explanations),
            "avg_latency_ms": float(np.mean(latencies)),
            "consistency": float(np.clip(consistency, 0, 1)),
            "hallucination_rate": hallucination_count / max(len(explanations), 1),
        }
