"""
Stage 2 — Depth Estimation (Depth-Anything V2)
Provides per-pixel and per-detection depth estimates.
"""
from __future__ import annotations
import numpy as np
import torch
import torch.nn.functional as F
from typing import Optional

try:
    from transformers import pipeline as hf_pipeline
    HF_AVAILABLE = True
except ImportError:
    HF_AVAILABLE = False


class DepthEstimator:
    """
    Wraps Depth-Anything V2 via HuggingFace Transformers.
    Returns normalised depth maps scaled to metric estimates.
    """

    def __init__(
        self,
        model_name: str = "depth-anything/Depth-Anything-V2-Base-hf",
        max_depth: float = 80.0,
        device: str = "cuda",
    ):
        self.max_depth = max_depth
        self.device = device
        self._pipe = None

        if HF_AVAILABLE:
            try:
                self._pipe = hf_pipeline(
                    task="depth-estimation",
                    model=model_name,
                    device=0 if device == "cuda" else -1,
                )
            except Exception as e:
                print(f"[DepthEstimator] Could not load model: {e} — using stub.")
        else:
            print("[DepthEstimator] transformers not found — using stub.")

    # ------------------------------------------------------------------
    def estimate(self, frame_rgb: np.ndarray) -> np.ndarray:
        """
        Args:
            frame_rgb: (H, W, 3) RGB uint8
        Returns:
            depth_map: (H, W) float32 in metres [0, max_depth]
        """
        if self._pipe is None:
            # Stub: return random depth scaled by distance-ish heuristic
            H, W = frame_rgb.shape[:2]
            stub = np.random.uniform(1.0, self.max_depth, (H, W)).astype(np.float32)
            return stub

        from PIL import Image
        pil_img = Image.fromarray(frame_rgb)
        result = self._pipe(pil_img)
        depth = np.array(result["depth"], dtype=np.float32)   # (H, W) normalised
        depth = depth / (depth.max() + 1e-6) * self.max_depth
        return depth

    # ------------------------------------------------------------------
    def depth_at_bbox(
        self,
        depth_map: np.ndarray,
        bbox_xyxy: np.ndarray,
        percentile: float = 10.0,
    ) -> float:
        """
        Returns the near-percentile depth within a bounding box
        (avoids background leakage by taking the low end).
        """
        H, W = depth_map.shape
        x1, y1, x2, y2 = bbox_xyxy.astype(int)
        x1, y1 = max(0, x1), max(0, y1)
        x2, y2 = min(W, x2), min(H, y2)

        if x2 <= x1 or y2 <= y1:
            return float(self.max_depth)

        patch = depth_map[y1:y2, x1:x2].flatten()
        return float(np.percentile(patch, percentile))

    # ------------------------------------------------------------------
    def annotate_detections(self, depth_map: np.ndarray, det_frame) -> None:
        """Fill the `.depth` field on each Detection in a DetectionFrame."""
        for det in det_frame.detections:
            det.depth = self.depth_at_bbox(depth_map, det.bbox_xyxy)
