"""
Stage 2 / Stage 4 — Visual Backbone (DINOv2 ViT-B/14)
Supports frozen inference and SSL-adapted fine-tuning.
"""
from __future__ import annotations
import torch
import torch.nn as nn
import timm
from typing import Optional


class DINOv2Backbone(nn.Module):
    """
    Wraps a DINOv2 ViT-B/14 backbone.
    - In frozen mode  : used for raw feature extraction.
    - In adapt mode   : a lightweight projection head is added for SSL.
    """

    def __init__(
        self,
        model_name: str = "vit_base_patch14_dinov2",
        pretrained: bool = True,
        freeze: bool = True,
        output_dim: int = 768,
        proj_dim: Optional[int] = None,   # if set, adds an SSL projection head
    ):
        super().__init__()
        self.output_dim = output_dim

        # Load backbone via timm
        self.encoder = timm.create_model(
            model_name,
            pretrained=pretrained,
            num_classes=0,      # remove classifier head
            global_pool="avg",  # global average pool → (B, 768)
        )

        if freeze:
            self._freeze_encoder()

        # Optional SSL projection head (MLP: D → proj_dim → proj_dim)
        self.proj_head: Optional[nn.Sequential] = None
        if proj_dim is not None:
            self.proj_head = nn.Sequential(
                nn.Linear(output_dim, proj_dim),
                nn.BatchNorm1d(proj_dim),
                nn.GELU(),
                nn.Linear(proj_dim, proj_dim),
            )

    # ------------------------------------------------------------------
    def _freeze_encoder(self) -> None:
        for p in self.encoder.parameters():
            p.requires_grad_(False)

    def unfreeze_last_n_blocks(self, n: int = 2) -> None:
        """Unfreeze the last n transformer blocks for domain adaptation."""
        blocks = list(self.encoder.blocks)
        for blk in blocks[-n:]:
            for p in blk.parameters():
                p.requires_grad_(True)

    # ------------------------------------------------------------------
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: (B, 3, H, W) — RGB image, normalised to ImageNet stats.
        Returns:
            h: (B, output_dim)  — visual feature vector
            z: (B, proj_dim)    — projected SSL embedding (if proj_head set)
        """
        h = self.encoder(x)           # (B, 768)
        if self.proj_head is not None:
            z = self.proj_head(h)
            return h, z
        return h, None

    # ------------------------------------------------------------------
    @staticmethod
    def build_transform(img_size: int = 224):
        """Standard DINOv2-compatible image transform."""
        from torchvision import transforms
        return transforms.Compose([
            transforms.Resize((img_size, img_size)),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225],
            ),
        ])
