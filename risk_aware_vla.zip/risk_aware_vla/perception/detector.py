"""
Stage 2 — YOLO-based Object Detection + Tracking
Wraps YOLOv8 with ByteTrack for persistent pedestrian/vehicle tracking.
"""
from __future__ import annotations
import numpy as np
import torch
from dataclasses import dataclass, field
from typing import List, Optional, Dict
from pathlib import Path

try:
    from ultralytics import YOLO
    YOLO_AVAILABLE = True
except ImportError:
    YOLO_AVAILABLE = False


@dataclass
class Detection:
    """Single detected object."""
    track_id: int
    class_id: int          # 0=person, 2=car, 5=bus, 7=truck
    class_name: str
    bbox_xyxy: np.ndarray  # [x1, y1, x2, y2] in pixels
    confidence: float
    depth: Optional[float] = None   # filled by depth module

    @property
    def center(self) -> np.ndarray:
        return np.array([
            (self.bbox_xyxy[0] + self.bbox_xyxy[2]) / 2,
            (self.bbox_xyxy[1] + self.bbox_xyxy[3]) / 2,
        ])

    @property
    def area(self) -> float:
        w = self.bbox_xyxy[2] - self.bbox_xyxy[0]
        h = self.bbox_xyxy[3] - self.bbox_xyxy[1]
        return float(w * h)

    def is_pedestrian(self) -> bool:
        return self.class_id == 0


@dataclass
class DetectionFrame:
    """All detections for one frame."""
    frame_id: int
    detections: List[Detection] = field(default_factory=list)

    def pedestrians(self) -> List[Detection]:
        return [d for d in self.detections if d.is_pedestrian()]

    def vehicles(self) -> List[Detection]:
        return [d for d in self.detections if not d.is_pedestrian()]

    def nearest_pedestrian(self) -> Optional[Detection]:
        peds = [d for d in self.pedestrians() if d.depth is not None]
        if not peds:
            return None
        return min(peds, key=lambda d: d.depth)  # type: ignore


CLASS_NAMES = {0: "person", 2: "car", 5: "bus", 7: "truck"}
TARGET_CLASSES = list(CLASS_NAMES.keys())


class YOLODetector:
    """
    Wraps YOLOv8 with optional ByteTrack tracking.
    Falls back to a stub if ultralytics is not installed.
    """

    def __init__(
        self,
        model_path: str = "yolov8m.pt",
        conf: float = 0.35,
        iou: float = 0.45,
        device: str = "cuda",
        track: bool = True,
    ):
        self.conf = conf
        self.iou = iou
        self.device = device
        self.track = track
        self._frame_id = 0

        if YOLO_AVAILABLE:
            self.model = YOLO(model_path)
            self.model.to(device)
        else:
            self.model = None
            print("[YOLODetector] ultralytics not found — running in stub mode.")

    # ------------------------------------------------------------------
    def detect(self, frame: np.ndarray) -> DetectionFrame:
        """
        Args:
            frame: (H, W, 3) BGR uint8 image (OpenCV format).
        Returns:
            DetectionFrame
        """
        self._frame_id += 1
        df = DetectionFrame(frame_id=self._frame_id)

        if self.model is None:
            return df   # stub: empty detections

        if self.track:
            results = self.model.track(
                frame,
                conf=self.conf,
                iou=self.iou,
                classes=TARGET_CLASSES,
                persist=True,
                verbose=False,
            )
        else:
            results = self.model.predict(
                frame,
                conf=self.conf,
                iou=self.iou,
                classes=TARGET_CLASSES,
                verbose=False,
            )

        if results and results[0].boxes is not None:
            boxes = results[0].boxes
            for i in range(len(boxes)):
                cls_id = int(boxes.cls[i].item())
                if cls_id not in CLASS_NAMES:
                    continue
                track_id = int(boxes.id[i].item()) if (self.track and boxes.id is not None) else -1
                df.detections.append(Detection(
                    track_id=track_id,
                    class_id=cls_id,
                    class_name=CLASS_NAMES[cls_id],
                    bbox_xyxy=boxes.xyxy[i].cpu().numpy(),
                    confidence=float(boxes.conf[i].item()),
                ))
        return df

    def reset_tracker(self) -> None:
        """Call at the start of each episode."""
        self._frame_id = 0
        if self.model is not None:
            self.model.reset_tracker()
