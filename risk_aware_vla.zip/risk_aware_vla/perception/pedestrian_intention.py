"""
Stage 1 / Stage 2 — Pedestrian Intention Pipeline
Implements the PIP-style crossing predictor + PIE/JAAD data pipeline.
"""
from __future__ import annotations
import torch
import torch.nn as nn
import numpy as np
from pathlib import Path
from typing import Optional, List, Tuple, Dict
import os


# ============================================================
# Data Pipeline — PIE / JAAD
# ============================================================

class PedestrianClipDataset(torch.utils.data.Dataset):
    """
    Loads pedestrian clips from PIE or JAAD.
    Expected directory layout:
        data/pie/
            clips/  (video clips or pre-extracted frames)
            annotations.csv   (columns: clip_id, frame_id, bbox_xyxy, crossing_label, ego_speed)
    """

    def __init__(
        self,
        root: str,
        split: str = "train",            # "train" | "val" | "test"
        clip_len: int = 16,
        img_size: Tuple[int, int] = (224, 224),
        transform=None,
    ):
        self.root = Path(root)
        self.split = split
        self.clip_len = clip_len
        self.img_size = img_size
        self.transform = transform
        self.samples = self._load_annotations()

    def _load_annotations(self) -> List[Dict]:
        """Load clip metadata. Override for real dataset."""
        import pandas as pd
        ann_file = self.root / "annotations.csv"
        if not ann_file.exists():
            print(f"[PedestrianClipDataset] annotations.csv not found at {ann_file}. Returning empty dataset.")
            return []
        df = pd.read_csv(ann_file)
        df = df[df["split"] == self.split]
        return df.to_dict("records")

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> Dict:
        sample = self.samples[idx]
        frames = self._load_clip(sample)    # (T, C, H, W)
        label = torch.tensor(sample["crossing_label"], dtype=torch.float32)
        ego_speed = torch.tensor(sample.get("ego_speed", 0.0), dtype=torch.float32)
        return {"frames": frames, "label": label, "ego_speed": ego_speed, "clip_id": sample["clip_id"]}

    def _load_clip(self, sample: Dict) -> torch.Tensor:
        """Load clip_len frames. Returns (T, C, H, W) tensor."""
        import cv2
        from torchvision import transforms
        clip_dir = self.root / "clips" / str(sample["clip_id"])
        frames = []
        if clip_dir.exists():
            frame_files = sorted(clip_dir.glob("*.jpg"))[:self.clip_len]
            for f in frame_files:
                img = cv2.imread(str(f))
                if img is None:
                    continue
                img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
                img = cv2.resize(img, self.img_size)
                frames.append(img)
        # Pad if needed
        while len(frames) < self.clip_len:
            frames.append(np.zeros((*self.img_size, 3), dtype=np.uint8))
        tensor = torch.from_numpy(np.stack(frames, 0)).permute(0, 3, 1, 2).float() / 255.0
        return tensor


# ============================================================
# PIP Model — Pedestrian Intention Predictor
# ============================================================

class PIPModel(nn.Module):
    """
    Pedestrian Intention Predictor.
    Architecture: lightweight spatial-temporal backbone → GRU → crossing probability.
    Based loosely on PIP (Pedestrian Intention Prediction).
    """

    def __init__(
        self,
        clip_len: int = 16,
        img_feat_dim: int = 512,
        ego_feat_dim: int = 16,
        hidden_dim: int = 256,
        num_layers: int = 2,
        dropout: float = 0.3,
    ):
        super().__init__()
        self.clip_len = clip_len

        # Spatial feature extractor (per-frame CNN)
        self.spatial_enc = nn.Sequential(
            nn.Conv2d(3, 32, 3, stride=2, padding=1), nn.ReLU(),
            nn.Conv2d(32, 64, 3, stride=2, padding=1), nn.ReLU(),
            nn.Conv2d(64, 128, 3, stride=2, padding=1), nn.ReLU(),
            nn.AdaptiveAvgPool2d((4, 4)),
            nn.Flatten(),
            nn.Linear(128 * 16, img_feat_dim),
            nn.ReLU(),
        )

        # Ego context encoder
        self.ego_enc = nn.Sequential(
            nn.Linear(1, ego_feat_dim), nn.ReLU(),
        )

        total_feat = img_feat_dim + ego_feat_dim

        # Temporal GRU
        self.gru = nn.GRU(
            input_size=total_feat,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            dropout=dropout,
            batch_first=True,
        )

        # Output head
        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim, 64),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(64, 1),
            nn.Sigmoid(),
        )

    def forward(
        self,
        frames: torch.Tensor,       # (B, T, C, H, W)
        ego_speed: torch.Tensor,    # (B,)
    ) -> torch.Tensor:              # (B,) crossing probability
        B, T, C, H, W = frames.shape

        # Encode each frame spatially
        frames_flat = frames.view(B * T, C, H, W)
        spatial_feats = self.spatial_enc(frames_flat).view(B, T, -1)    # (B, T, img_feat_dim)

        # Repeat ego speed along time axis
        ego_feats = self.ego_enc(ego_speed.unsqueeze(-1))                # (B, ego_feat_dim)
        ego_feats = ego_feats.unsqueeze(1).expand(-1, T, -1)             # (B, T, ego_feat_dim)

        combined = torch.cat([spatial_feats, ego_feats], dim=-1)         # (B, T, total_feat)
        gru_out, _ = self.gru(combined)
        last = gru_out[:, -1, :]                                         # (B, hidden_dim)
        return self.classifier(last).squeeze(-1)                          # (B,)


# ============================================================
# Inference Wrapper
# ============================================================

class PedestrianIntentionInference:
    """
    Maintains a sliding window of frames per track and produces pcross.
    Used during the closed-loop CARLA evaluation.
    """

    def __init__(
        self,
        model_path: Optional[str] = None,
        clip_len: int = 16,
        img_size: Tuple[int, int] = (224, 224),
        device: str = "cuda",
    ):
        self.clip_len = clip_len
        self.img_size = img_size
        self.device = device
        self._buffers: Dict[int, List[np.ndarray]] = {}   # track_id → frames

        self.model = PIPModel(clip_len=clip_len)
        if model_path and Path(model_path).exists():
            ckpt = torch.load(model_path, map_location=device)
            self.model.load_state_dict(ckpt["model_state_dict"])
            print(f"[PIP] Loaded weights from {model_path}")
        self.model.eval().to(device)

    def update(
        self,
        track_id: int,
        crop: np.ndarray,
        ego_speed: float,
    ) -> float:
        """
        Feed one crop for a given pedestrian track.
        Returns pcross ∈ [0, 1].
        """
        import cv2
        crop_resized = cv2.resize(crop, self.img_size)
        buf = self._buffers.setdefault(track_id, [])
        buf.append(crop_resized)
        if len(buf) > self.clip_len:
            buf.pop(0)

        # Pad if buffer is not full yet
        frames = buf.copy()
        while len(frames) < self.clip_len:
            frames.insert(0, np.zeros((*self.img_size, 3), dtype=np.uint8))

        tensor = torch.from_numpy(np.stack(frames, 0)).permute(0, 3, 1, 2).float() / 255.0
        tensor = tensor.unsqueeze(0).to(self.device)      # (1, T, C, H, W)
        speed_t = torch.tensor([[ego_speed]], dtype=torch.float32).to(self.device)

        with torch.no_grad():
            prob = self.model(tensor, speed_t).item()
        return float(prob)

    def reset(self) -> None:
        self._buffers.clear()
