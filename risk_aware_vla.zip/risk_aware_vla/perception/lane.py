"""
Stage 2 — Lane Detection
Lightweight lane-center error and boundary estimation.
Uses an ultra-fast lane model or falls back to a simple stub.
"""
from __future__ import annotations
import numpy as np
import cv2
from dataclasses import dataclass
from typing import Optional, Tuple


@dataclass
class LaneInfo:
    """Output of the lane detector for one frame."""
    left_boundary: Optional[np.ndarray]    # (N, 2) pixel coords
    right_boundary: Optional[np.ndarray]   # (N, 2) pixel coords
    lane_center_error: float               # signed offset in pixels (+ = right of lane)
    lane_width_px: float
    detected: bool


class LaneDetector:
    """
    Wraps an ultra-fast lane detector.
    Falls back to a classical CV pipeline (Canny + Hough) if the model
    is unavailable, which is sufficient for CARLA structured roads.
    """

    def __init__(
        self,
        model_path: Optional[str] = None,
        conf_threshold: float = 0.5,
        img_width: int = 640,
        img_height: int = 480,
    ):
        self.img_width = img_width
        self.img_height = img_height
        self.model = None   # plug in ultra-fast-lane-detection here if available

    # ------------------------------------------------------------------
    def detect(self, frame_bgr: np.ndarray) -> LaneInfo:
        """
        Args:
            frame_bgr: (H, W, 3) uint8 BGR
        Returns:
            LaneInfo
        """
        if self.model is not None:
            return self._model_detect(frame_bgr)
        return self._classical_detect(frame_bgr)

    # ------------------------------------------------------------------
    def _classical_detect(self, frame_bgr: np.ndarray) -> LaneInfo:
        """Classical Canny + Hough fallback — works well in CARLA."""
        H, W = frame_bgr.shape[:2]
        gray = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2GRAY)
        blur = cv2.GaussianBlur(gray, (5, 5), 0)
        edges = cv2.Canny(blur, 50, 150)

        # Region of interest: lower half trapezoid
        mask = np.zeros_like(edges)
        roi = np.array([[
            (0, H),
            (int(W * 0.45), int(H * 0.55)),
            (int(W * 0.55), int(H * 0.55)),
            (W, H),
        ]], dtype=np.int32)
        cv2.fillPoly(mask, roi, 255)
        masked = cv2.bitwise_and(edges, mask)

        lines = cv2.HoughLinesP(masked, 1, np.pi / 180, 50, minLineLength=50, maxLineGap=100)

        left_pts, right_pts = [], []
        cx = W / 2.0

        if lines is not None:
            for line in lines:
                x1, y1, x2, y2 = line[0]
                if x2 == x1:
                    continue
                slope = (y2 - y1) / (x2 - x1)
                if abs(slope) < 0.3:
                    continue
                if slope < 0 and x1 < cx and x2 < cx:
                    left_pts.extend([(x1, y1), (x2, y2)])
                elif slope > 0 and x1 > cx and x2 > cx:
                    right_pts.extend([(x1, y1), (x2, y2)])

        def fit_lane(pts):
            if len(pts) < 2:
                return None
            pts = np.array(pts)
            m, b = np.polyfit(pts[:, 0], pts[:, 1], 1)
            ys = np.linspace(int(H * 0.55), H, 20)
            xs = (ys - b) / (m + 1e-9)
            return np.stack([xs, ys], axis=1)

        left = fit_lane(left_pts)
        right = fit_lane(right_pts)

        # Lane center error: positive = ego is right of centre
        lane_center_error = 0.0
        lane_width_px = 0.0
        detected = False

        if left is not None and right is not None:
            lx = float(left[-1, 0])
            rx = float(right[-1, 0])
            lane_cx = (lx + rx) / 2.0
            lane_center_error = float(cx - lane_cx)  # ego offset from lane centre
            lane_width_px = float(rx - lx)
            detected = True
        elif left is not None:
            lane_center_error = float(cx - left[-1, 0]) - 180.0
        elif right is not None:
            lane_center_error = float(cx - right[-1, 0]) + 180.0

        return LaneInfo(
            left_boundary=left,
            right_boundary=right,
            lane_center_error=lane_center_error,
            lane_width_px=lane_width_px,
            detected=detected,
        )

    def _model_detect(self, frame_bgr: np.ndarray) -> LaneInfo:
        raise NotImplementedError("Plug in ultra-fast-lane-detection model here.")

    # ------------------------------------------------------------------
    def normalised_error(self, lane_info: LaneInfo) -> float:
        """Return lane centre error normalised to [-1, 1]."""
        if lane_info.lane_width_px > 0:
            return np.clip(lane_info.lane_center_error / (lane_info.lane_width_px / 2), -1, 1)
        return float(np.clip(lane_info.lane_center_error / 200.0, -1, 1))
