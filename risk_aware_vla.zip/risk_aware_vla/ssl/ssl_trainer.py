"""
Stage 4 — Self-Supervised Visual Adaptation
VICReg-style objective:
  L_SSL = ||z1 - z2||^2  +  λ_var * L_var  +  λ_cov * L_cov
Applied to DINOv2 backbone + projection head using unlabeled CARLA/PIE frames.
"""
from __future__ import annotations
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
import numpy as np
from pathlib import Path
from typing import Tuple, Optional
import albumentations as A
from albumentations.pytorch import ToTensorV2
import cv2


# ============================================================
# Augmentation Pipeline
# ============================================================

def build_ssl_augmentation(cfg: dict) -> A.Compose:
    return A.Compose([
        A.RandomResizedCrop(height=224, width=224, scale=(0.5, 1.0)),
        A.HorizontalFlip(p=cfg.get("horizontal_flip", 0.5)),
        A.ColorJitter(
            brightness=cfg.get("color_jitter", 0.4),
            contrast=cfg.get("color_jitter", 0.4),
            saturation=cfg.get("color_jitter", 0.4),
            hue=0.1,
            p=0.8,
        ),
        A.ToGray(p=cfg.get("gray_scale", 0.2)),
        A.GaussianBlur(blur_limit=(3, 7), p=cfg.get("gaussian_blur", 0.5)),
        A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ToTensorV2(),
    ])


# ============================================================
# Unlabeled Frame Dataset
# ============================================================

class UnlabeledFrameDataset(Dataset):
    """
    Loads unlabeled frames from CARLA rollouts, PIE clips, or JAAD.
    Each item returns two augmented views of the same frame.
    """

    def __init__(self, frame_dir: str, augmentation: A.Compose):
        self.paths = sorted(Path(frame_dir).rglob("*.jpg")) + \
                     sorted(Path(frame_dir).rglob("*.png"))
        self.aug = augmentation
        print(f"[SSL Dataset] Found {len(self.paths)} frames in {frame_dir}")

    def __len__(self) -> int:
        return len(self.paths)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        img = cv2.imread(str(self.paths[idx]))
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        view1 = self.aug(image=img)["image"]
        view2 = self.aug(image=img)["image"]
        return view1, view2


# ============================================================
# VICReg Loss Components
# ============================================================

def vicreg_invariance_loss(z1: torch.Tensor, z2: torch.Tensor) -> torch.Tensor:
    """Mean squared error between two views."""
    return F.mse_loss(z1, z2)


def vicreg_variance_loss(z: torch.Tensor, gamma: float = 1.0, eps: float = 1e-4) -> torch.Tensor:
    """Variance hinge: push std of each feature dimension above gamma."""
    std = torch.sqrt(z.var(dim=0) + eps)
    return F.relu(gamma - std).mean()


def vicreg_covariance_loss(z: torch.Tensor) -> torch.Tensor:
    """Covariance penalty: decorrelate feature dimensions."""
    B, D = z.shape
    z = z - z.mean(dim=0)
    cov = (z.T @ z) / (B - 1)
    off_diag = cov.pow(2).sum() - cov.diagonal().pow(2).sum()
    return off_diag / D


# ============================================================
# SSL Trainer
# ============================================================

class SSLTrainer:
    """
    Full SSL training loop for DINOv2 adaptation.
    """

    def __init__(
        self,
        backbone,                          # DINOv2Backbone (with proj_head)
        cfg: dict,
        device: str = "cuda",
        log_dir: str = "logs/ssl",
    ):
        self.backbone = backbone.to(device)
        self.cfg = cfg
        self.device = device
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)

        self.lambda_var = cfg.get("lambda_var", 1.0)
        self.lambda_cov = cfg.get("lambda_cov", 0.04)

        # Unfreeze last 2 blocks + projection head
        self.backbone.unfreeze_last_n_blocks(2)
        self.optimizer = torch.optim.AdamW(
            filter(lambda p: p.requires_grad, self.backbone.parameters()),
            lr=cfg.get("lr", 1e-4),
            weight_decay=cfg.get("weight_decay", 1e-4),
        )
        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            self.optimizer, T_max=cfg.get("epochs", 50)
        )

    # ------------------------------------------------------------------
    def train(
        self,
        dataset: UnlabeledFrameDataset,
        epochs: Optional[int] = None,
        save_path: str = "checkpoints/ssl_backbone.pth",
    ) -> dict:
        """Full training run. Returns loss history."""
        from torch.utils.tensorboard import SummaryWriter
        writer = SummaryWriter(str(self.log_dir))

        n_epochs = epochs or self.cfg.get("epochs", 50)
        batch_size = self.cfg.get("batch_size", 64)
        loader = DataLoader(dataset, batch_size=batch_size, shuffle=True,
                            num_workers=4, pin_memory=True, drop_last=True)

        history = {"loss": [], "inv": [], "var": [], "cov": []}

        for epoch in range(n_epochs):
            self.backbone.train()
            epoch_loss = epoch_inv = epoch_var = epoch_cov = 0.0

            for step, (v1, v2) in enumerate(loader):
                v1, v2 = v1.to(self.device), v2.to(self.device)

                _, z1 = self.backbone(v1)
                _, z2 = self.backbone(v2)

                if z1 is None:
                    raise RuntimeError("Backbone must have proj_head for SSL training.")

                l_inv = vicreg_invariance_loss(z1, z2)
                l_var = (vicreg_variance_loss(z1) + vicreg_variance_loss(z2)) / 2
                l_cov = (vicreg_covariance_loss(z1) + vicreg_covariance_loss(z2)) / 2
                loss = l_inv + self.lambda_var * l_var + self.lambda_cov * l_cov

                self.optimizer.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.backbone.parameters(), 1.0)
                self.optimizer.step()

                epoch_loss += loss.item()
                epoch_inv += l_inv.item()
                epoch_var += l_var.item()
                epoch_cov += l_cov.item()

            N = len(loader)
            self.scheduler.step()
            avg_loss = epoch_loss / N

            history["loss"].append(avg_loss)
            history["inv"].append(epoch_inv / N)
            history["var"].append(epoch_var / N)
            history["cov"].append(epoch_cov / N)

            writer.add_scalar("ssl/loss", avg_loss, epoch)
            print(f"[SSL] Epoch {epoch+1}/{n_epochs} | Loss={avg_loss:.4f} "
                  f"Inv={epoch_inv/N:.4f} Var={epoch_var/N:.4f} Cov={epoch_cov/N:.4f}")

            if (epoch + 1) % 10 == 0:
                self._save(save_path, epoch)

        self._save(save_path, n_epochs - 1)
        writer.close()
        return history

    def _save(self, path: str, epoch: int) -> None:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        torch.save({
            "epoch": epoch,
            "model_state_dict": self.backbone.state_dict(),
            "optimizer_state_dict": self.optimizer.state_dict(),
        }, path)
        print(f"[SSL] Saved checkpoint → {path}")
