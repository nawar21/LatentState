"""
Final Evaluation Module
Runs the full evaluation suite across 5 scene types.
Computes all metrics: collision rate, CVaR return, latent RMSE, explanation quality.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from pathlib import Path
from typing import Dict, List, Optional, Callable
from dataclasses import dataclass, field
import json


@dataclass
class EpisodeResult:
    scene_type: str
    total_reward: float
    n_steps: int
    collision: bool
    route_completion: float
    n_peeks: int
    latent_rmse: Optional[float] = None
    explanation_texts: List[str] = field(default_factory=list)


@dataclass
class EvalSummary:
    scene_type: str
    n_episodes: int
    collision_rate: float
    mean_return: float
    cvar_return: float        # CVaR at α=0.05
    route_completion: float
    n_peeks_per_ep: float
    latent_rmse: Optional[float] = None
    explanation_consistency: Optional[float] = None

    def to_dict(self) -> dict:
        return {
            "scene_type": self.scene_type,
            "n_episodes": self.n_episodes,
            "collision_rate": round(self.collision_rate, 4),
            "mean_return": round(self.mean_return, 4),
            "cvar_return_05": round(self.cvar_return, 4),
            "route_completion": round(self.route_completion, 4),
            "n_peeks_per_ep": round(self.n_peeks_per_ep, 2),
            "latent_rmse": round(self.latent_rmse, 4) if self.latent_rmse else None,
            "explanation_consistency": round(self.explanation_consistency, 4) if self.explanation_consistency else None,
        }


def compute_cvar(returns: np.ndarray, alpha: float = 0.05) -> float:
    """CVaR_α(R) = E[R | R ≤ VaR_α(R)]"""
    k = max(1, int(len(returns) * alpha))
    sorted_r = np.sort(returns)
    return float(sorted_r[:k].mean())


class Evaluator:
    """
    Runs the full evaluation protocol:
    1. Easy clear scenes
    2. Visible pedestrian scenes
    3. Hidden pedestrian scenes
    4. Blind-corner scenes
    5. Domain-randomized scenes
    """

    SCENE_TYPES = [
        "easy_clear",
        "visible_pedestrian",
        "hidden_pedestrian",
        "blind_corner",
        "domain_randomized",
    ]

    def __init__(
        self,
        cfg: dict,
        log_dir: str = "logs/eval",
        alpha_cvar: float = 0.05,
    ):
        self.cfg = cfg
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.alpha = alpha_cvar

    # ------------------------------------------------------------------
    def evaluate_policy(
        self,
        policy,                   # callable: obs → action (np.ndarray)
        env_factory: Callable,    # callable: (scene_type) → gym.Env
        n_episodes: int = 20,
        explainer=None,
        label_computer=None,
    ) -> Dict[str, EvalSummary]:
        """
        Run full evaluation across all scene types.
        Returns a dict mapping scene_type → EvalSummary.
        """
        results: Dict[str, List[EpisodeResult]] = {s: [] for s in self.SCENE_TYPES}

        for scene in self.SCENE_TYPES:
            print(f"\n[Eval] Scene: {scene}")
            env = env_factory(scene)

            for ep in range(n_episodes):
                result = self._run_episode(
                    policy, env, scene, explainer, label_computer
                )
                results[scene].append(result)
                if (ep + 1) % 5 == 0:
                    print(f"  Episode {ep+1}/{n_episodes} | "
                          f"R={result.total_reward:.2f} | "
                          f"Coll={result.collision} | "
                          f"Comp={result.route_completion:.2f}")
            env.close()

        summaries = {s: self._summarise(s, eps) for s, eps in results.items()}
        self._save_results(summaries)
        self._plot_results(summaries)
        return summaries

    # ------------------------------------------------------------------
    def _run_episode(
        self,
        policy,
        env,
        scene_type: str,
        explainer=None,
        label_computer=None,
    ) -> EpisodeResult:
        obs, _ = env.reset()
        total_reward = 0.0
        n_steps = 0
        n_peeks = 0
        collision = False
        latent_errors = []
        explanations = []

        while True:
            action = policy(obs)
            next_obs, reward, terminated, truncated, info = env.step(action)
            total_reward += reward
            n_steps += 1

            if info.get("r_peek", 0) > 0:
                n_peeks += 1
            if info.get("collision", False):
                collision = True

            # Explanation
            if explainer is not None and n_steps % 20 == 0:
                exp = explainer.explain(obs, action, force=True)
                if exp:
                    explanations.append(exp.text)

            obs = next_obs
            if terminated or truncated:
                break

        route_completion = float(min(1.0, info.get("episode", {}).get("r", 0) / 100.0 + 0.5))
        latent_rmse = float(np.mean(latent_errors)) if latent_errors else None

        return EpisodeResult(
            scene_type=scene_type,
            total_reward=total_reward,
            n_steps=n_steps,
            collision=collision,
            route_completion=route_completion,
            n_peeks=n_peeks,
            latent_rmse=latent_rmse,
            explanation_texts=explanations,
        )

    # ------------------------------------------------------------------
    def _summarise(self, scene_type: str, episodes: List[EpisodeResult]) -> EvalSummary:
        returns = np.array([e.total_reward for e in episodes])
        collisions = np.array([float(e.collision) for e in episodes])
        completions = np.array([e.route_completion for e in episodes])
        peeks = np.array([e.n_peeks for e in episodes])
        rmse_vals = [e.latent_rmse for e in episodes if e.latent_rmse is not None]

        all_texts = [t for e in episodes for t in e.explanation_texts]
        consistency = None
        if all_texts:
            lengths = [len(t.split()) for t in all_texts]
            consistency = float(1.0 - np.std(lengths) / (np.mean(lengths) + 1e-6))

        return EvalSummary(
            scene_type=scene_type,
            n_episodes=len(episodes),
            collision_rate=float(collisions.mean()),
            mean_return=float(returns.mean()),
            cvar_return=compute_cvar(returns, self.alpha),
            route_completion=float(completions.mean()),
            n_peeks_per_ep=float(peeks.mean()),
            latent_rmse=float(np.mean(rmse_vals)) if rmse_vals else None,
            explanation_consistency=consistency,
        )

    # ------------------------------------------------------------------
    def _save_results(self, summaries: Dict[str, EvalSummary]) -> None:
        records = [s.to_dict() for s in summaries.values()]
        df = pd.DataFrame(records)
        csv_path = self.log_dir / "eval_results.csv"
        df.to_csv(csv_path, index=False)

        json_path = self.log_dir / "eval_results.json"
        with open(json_path, "w") as f:
            json.dump(records, f, indent=2)

        print(f"\n[Eval] Results saved → {csv_path}")
        print(df.to_string(index=False))

    def _plot_results(self, summaries: Dict[str, EvalSummary]) -> None:
        scenes = list(summaries.keys())
        metrics = {
            "Collision Rate": [summaries[s].collision_rate for s in scenes],
            "Mean Return": [summaries[s].mean_return for s in scenes],
            "CVaR Return": [summaries[s].cvar_return for s in scenes],
            "Route Completion": [summaries[s].route_completion for s in scenes],
        }

        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
        axes = axes.flatten()
        colors = ["#e74c3c", "#2ecc71", "#3498db", "#f39c12"]

        for i, (metric, vals) in enumerate(metrics.items()):
            ax = axes[i]
            bars = ax.bar(scenes, vals, color=colors[i], alpha=0.85, edgecolor="white")
            ax.set_title(metric, fontweight="bold", fontsize=12)
            ax.set_xticklabels(scenes, rotation=20, ha="right", fontsize=9)
            for bar, val in zip(bars, vals):
                ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.01,
                        f"{val:.3f}", ha="center", va="bottom", fontsize=8)
            ax.grid(axis="y", alpha=0.3)

        plt.suptitle("Risk-Aware VLA — Final Evaluation", fontweight="bold", fontsize=14)
        plt.tight_layout()
        fig_path = self.log_dir / "eval_results.png"
        plt.savefig(fig_path, dpi=150, bbox_inches="tight")
        plt.close()
        print(f"[Eval] Plot saved → {fig_path}")

    # ------------------------------------------------------------------
    def compare_baselines(
        self,
        baselines: Dict[str, Dict],   # {"PPO on true Z": {scene: EvalSummary, ...}, ...}
        save_prefix: str = "comparison",
    ) -> None:
        """
        Plot a comparison table across baselines for each metric.
        baselines: dict of {model_name: {scene_type: EvalSummary}}
        """
        scenes = self.SCENE_TYPES
        model_names = list(baselines.keys())

        fig, axes = plt.subplots(1, 2, figsize=(16, 6))

        # Collision rate comparison
        ax = axes[0]
        x = np.arange(len(scenes))
        width = 0.8 / len(model_names)
        for i, name in enumerate(model_names):
            vals = [baselines[name].get(s, EvalSummary(s,0,0,0,0,0,0)).collision_rate for s in scenes]
            ax.bar(x + i * width, vals, width=width * 0.9, label=name, alpha=0.8)
        ax.set_xticks(x + width * len(model_names) / 2)
        ax.set_xticklabels(scenes, rotation=20, ha="right")
        ax.set_title("Collision Rate ↓", fontweight="bold")
        ax.legend(fontsize=8)
        ax.grid(axis="y", alpha=0.3)

        # CVaR return comparison
        ax = axes[1]
        for i, name in enumerate(model_names):
            vals = [baselines[name].get(s, EvalSummary(s,0,0,0,0,0,0)).cvar_return for s in scenes]
            ax.bar(x + i * width, vals, width=width * 0.9, label=name, alpha=0.8)
        ax.set_xticks(x + width * len(model_names) / 2)
        ax.set_xticklabels(scenes, rotation=20, ha="right")
        ax.set_title("CVaR Return (α=5%) ↑", fontweight="bold")
        ax.legend(fontsize=8)
        ax.grid(axis="y", alpha=0.3)

        plt.suptitle("Baseline Comparison", fontweight="bold", fontsize=14)
        plt.tight_layout()
        path = self.log_dir / f"{save_prefix}.png"
        plt.savefig(path, dpi=150, bbox_inches="tight")
        plt.close()
        print(f"[Eval] Comparison plot saved → {path}")
