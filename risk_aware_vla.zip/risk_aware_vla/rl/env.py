"""
Stage 7–10 — CARLA Gymnasium Environment
Supports:
  - True-Z mode (Stage 7–9): uses CARLA ground-truth latent labels
  - Predicted-Zhat mode (Stage 10): uses the fusion head's prediction
  - Domain randomization (Stage 6)
  - Active peeking reward shaping (Stage 9)
"""
from __future__ import annotations
import gymnasium as gym
import numpy as np
import math
from typing import Optional, Dict, Any, Tuple
from pathlib import Path

# CARLA Python API (must be installed separately)
try:
    import carla
    CARLA_AVAILABLE = True
except ImportError:
    CARLA_AVAILABLE = False
    print("[CARLAEnv] CARLA Python API not found — running in mock mode.")


LATENT_DIM = 10
ACTION_DIM = 3   # [steer, throttle, brake]


class CARLADrivingEnv(gym.Env):
    """
    Gymnasium-compatible CARLA driving environment.
    Observation: latent vector Z (10-dim)
    Action:      [steer ∈ [-1,1], throttle ∈ [0,1], brake ∈ [0,1]]
    """

    metadata = {"render_modes": ["human", "rgb_array"]}

    def __init__(self, cfg: dict, mode: str = "true_z", render_mode: str = "rgb_array"):
        super().__init__()
        self.cfg = cfg
        self.mode = mode          # "true_z" or "predicted_z"
        self.render_mode = render_mode

        # Spaces
        self.observation_space = gym.spaces.Box(
            low=-1.0, high=1.0, shape=(LATENT_DIM,), dtype=np.float32
        )
        self.action_space = gym.spaces.Box(
            low=np.array([-1.0, 0.0, 0.0]),
            high=np.array([1.0, 1.0, 1.0]),
            dtype=np.float32,
        )

        # Internal state
        self._world = None
        self._vehicle = None
        self._camera = None
        self._collision_sensor = None
        self._step_count = 0
        self._max_steps = 1000
        self._last_frame: Optional[np.ndarray] = None
        self._collision_occurred = False
        self._prev_location = None
        self._prev_velocity = 0.0
        self._episode_distance = 0.0
        self._route_waypoints = []

        # Reward weights from config
        rw = cfg.get("ppo", {}).get("reward", {})
        self.w_progress = rw.get("progress_scale", 1.0)
        self.w_lane     = rw.get("lane_penalty", 0.5)
        self.w_jerk     = rw.get("jerk_penalty", 0.1)
        self.w_coll     = rw.get("collision_penalty", 10.0)
        self.w_speed    = rw.get("unsafe_speed_penalty", 0.3)
        self.w_near     = rw.get("near_miss_penalty", 2.0)
        self.w_peek     = cfg.get("peeking", {}).get("reward_scale", 0.3)

        # Perception modules (set via set_perception_modules)
        self._label_computer = None
        self._fusion_head = None
        self._pip = None
        self._lane_detector = None
        self._depth_estimator = None
        self._yolo = None
        self._backbone = None

        if CARLA_AVAILABLE:
            self._connect()

    # ------------------------------------------------------------------
    # External module injection
    # ------------------------------------------------------------------
    def set_perception_modules(self, **kwargs):
        """Inject perception modules after construction."""
        for k, v in kwargs.items():
            setattr(self, f"_{k}", v)

    # ------------------------------------------------------------------
    # CARLA Connection
    # ------------------------------------------------------------------
    def _connect(self):
        client = carla.Client(
            self.cfg["carla"]["host"],
            self.cfg["carla"]["port"],
        )
        client.set_timeout(self.cfg["carla"]["timeout"])
        self._world = client.load_world(self.cfg["carla"]["town"])
        settings = self._world.get_settings()
        settings.synchronous_mode = True
        settings.fixed_delta_seconds = 1.0 / self.cfg["carla"]["fps"]
        self._world.apply_settings(settings)
        self._client = client

    # ------------------------------------------------------------------
    # gym.Env interface
    # ------------------------------------------------------------------
    def reset(
        self,
        seed: Optional[int] = None,
        options: Optional[dict] = None,
    ) -> Tuple[np.ndarray, dict]:
        super().reset(seed=seed)
        self._step_count = 0
        self._collision_occurred = False
        self._episode_distance = 0.0
        self._prev_location = None
        self._prev_velocity = 0.0

        if not CARLA_AVAILABLE or self._world is None:
            return self._mock_obs(), {}

        self._destroy_actors()
        self._spawn_ego()
        self._attach_sensors()
        self._spawn_traffic()

        if self.cfg.get("domain_rand", {}).get("enabled", False):
            self._apply_domain_randomization()

        self._world.tick()
        obs = self._get_observation()
        return obs, {}

    def step(
        self, action: np.ndarray
    ) -> Tuple[np.ndarray, float, bool, bool, dict]:
        self._step_count += 1

        if not CARLA_AVAILABLE or self._vehicle is None:
            obs = self._mock_obs()
            reward = float(np.random.randn() * 0.1)
            done = self._step_count >= self._max_steps
            return obs, reward, done, False, {}

        # Apply action
        steer, throttle, brake = float(action[0]), float(action[1]), float(action[2])
        control = carla.VehicleControl(
            throttle=np.clip(throttle, 0, 1),
            steer=np.clip(steer, -1, 1),
            brake=np.clip(brake, 0, 1),
        )
        self._vehicle.apply_control(control)
        self._world.tick()

        obs = self._get_observation()
        reward, info = self._compute_reward(obs, action)
        terminated = self._collision_occurred
        truncated = self._step_count >= self._max_steps

        return obs, reward, terminated, truncated, info

    def render(self) -> Optional[np.ndarray]:
        return self._last_frame

    def close(self):
        self._destroy_actors()
        if CARLA_AVAILABLE and self._world is not None:
            settings = self._world.get_settings()
            settings.synchronous_mode = False
            self._world.apply_settings(settings)

    # ------------------------------------------------------------------
    # Observation
    # ------------------------------------------------------------------
    def _get_observation(self) -> np.ndarray:
        """Build the latent observation vector."""
        if self.mode == "true_z":
            return self._compute_true_z()
        else:
            return self._compute_predicted_z()

    def _compute_true_z(self) -> np.ndarray:
        """Compute Z directly from CARLA simulator state (Stage 7–9)."""
        from latent.labels import CarlaState, LatentLabelComputer
        if self._label_computer is None:
            return self._mock_obs()

        state = self._build_carla_state()
        pcross = self._get_pcross(state)
        lane_err = self._get_lane_error()
        label = self._label_computer.compute(state, pcross=pcross, lane_error_norm=lane_err)
        return label.to_array()

    def _compute_predicted_z(self) -> np.ndarray:
        """Predict Z using fusion head (Stage 10)."""
        if self._fusion_head is None or self._backbone is None:
            return self._compute_true_z()

        import torch
        frame_rgb = self._last_frame
        if frame_rgb is None:
            return self._mock_obs()

        from perception.backbone import DINOv2Backbone
        transform = DINOv2Backbone.build_transform()
        from PIL import Image
        pil = Image.fromarray(frame_rgb)
        img_t = transform(pil).unsqueeze(0).to(next(self._backbone.parameters()).device)

        with torch.no_grad():
            h, _ = self._backbone(img_t)
            # Build dummy modality tensors from partial CARLA state
            det_t   = torch.zeros(1, 20, 9)
            depth_t = torch.zeros(1, 480, 640)
            lane_t  = torch.zeros(1, 3)
            state   = self._build_carla_state()
            pcross  = self._get_pcross(state)
            v_norm  = np.clip(state.ego_velocity / 15.0, 0, 1)
            yr_norm = np.clip(state.ego_yaw_rate / 1.5, -1, 1)
            scalars_t = torch.tensor([[pcross, v_norm, yr_norm]], dtype=torch.float32)
            z_hat, _ = self._fusion_head(h, det_t, depth_t, lane_t, scalars_t)
        return z_hat.squeeze(0).cpu().numpy()

    # ------------------------------------------------------------------
    # Reward
    # ------------------------------------------------------------------
    def _compute_reward(self, obs: np.ndarray, action: np.ndarray) -> Tuple[float, dict]:
        """
        r_t = r_progress − λ1|elane| − λ2*r_jerk − λ3*1_collision
              − λ4*r_unsafe_speed − λ5*r_near_miss + λ_peek*1_safe_peek
        """
        elane    = float(abs(obs[8]))
        v        = float(obs[7])
        oc       = float(obs[1])
        pcoll    = float(obs[3])
        dped     = float(obs[6])

        r_progress = self._progress_reward()
        r_jerk     = self._jerk_reward(action)
        r_coll     = float(self._collision_occurred) * self.w_coll
        r_speed    = float(v > 0.8) * self.w_speed   # penalise unsafe speed
        r_near     = float(pcoll > 0.7) * self.w_near

        # Active peeking: reward slow careful approach to occluded zone
        r_peek = 0.0
        peek_cfg = self.cfg.get("peeking", {})
        if (peek_cfg.get("enabled", False)
                and oc > peek_cfg.get("occlusion_threshold", 0.6)
                and v < peek_cfg.get("peek_speed_limit", 2.0) / 15.0):
            r_peek = self.w_peek

        reward = (
            self.w_progress * r_progress
            - self.w_lane * elane
            - self.w_jerk * r_jerk
            - r_coll
            - r_speed
            - r_near
            + r_peek
        )

        info = {
            "r_progress": r_progress,
            "r_lane": -self.w_lane * elane,
            "r_coll": -r_coll,
            "r_peek": r_peek,
            "collision": self._collision_occurred,
        }
        return float(reward), info

    def _progress_reward(self) -> float:
        if not CARLA_AVAILABLE or self._vehicle is None:
            return 0.0
        loc = self._vehicle.get_location()
        current = np.array([loc.x, loc.y])
        if self._prev_location is None:
            self._prev_location = current
            return 0.0
        dist = float(np.linalg.norm(current - self._prev_location))
        self._episode_distance += dist
        self._prev_location = current
        return dist

    def _jerk_reward(self, action: np.ndarray) -> float:
        v = float(action[1] - action[2])
        jerk = abs(v - self._prev_velocity)
        self._prev_velocity = v
        return jerk

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _build_carla_state(self):
        from latent.labels import CarlaState
        if not CARLA_AVAILABLE or self._vehicle is None:
            return CarlaState(
                ego_velocity=0.0, ego_yaw_rate=0.0,
                ego_location=np.zeros(3), ego_heading=0.0,
            )
        vel = self._vehicle.get_velocity()
        speed = math.sqrt(vel.x**2 + vel.y**2 + vel.z**2)
        tr = self._vehicle.get_transform()
        heading = math.radians(tr.rotation.yaw)
        loc = np.array([tr.location.x, tr.location.y, tr.location.z])

        ang_vel = self._vehicle.get_angular_velocity()
        yaw_rate = math.radians(ang_vel.z)

        pedestrians, vehicles = [], []
        for actor in self._world.get_actors():
            if "walker" in actor.type_id:
                a_tr = actor.get_transform()
                a_vel = actor.get_velocity()
                # Simple occlusion: check CARLA raycast or placeholder
                pedestrians.append({
                    "id": actor.id,
                    "location": [a_tr.location.x, a_tr.location.y, a_tr.location.z],
                    "velocity": [a_vel.x, a_vel.y],
                    "occluded": False,  # replace with raycast check
                })
            elif "vehicle" in actor.type_id and actor.id != self._vehicle.id:
                a_tr = actor.get_transform()
                a_vel = actor.get_velocity()
                vehicles.append({
                    "id": actor.id,
                    "location": [a_tr.location.x, a_tr.location.y, a_tr.location.z],
                    "velocity": [a_vel.x, a_vel.y],
                })

        return CarlaState(
            ego_velocity=speed,
            ego_yaw_rate=yaw_rate,
            ego_location=loc,
            ego_heading=heading,
            pedestrians=pedestrians,
            vehicles=vehicles,
            collision_occurred=self._collision_occurred,
        )

    def _get_pcross(self, state) -> float:
        if self._pip is None:
            return 0.0
        peds = state.pedestrians
        if not peds:
            return 0.0
        # Use nearest pedestrian
        ego = state.ego_location[:2]
        nearest = min(peds, key=lambda p: np.linalg.norm(np.array(p["location"][:2]) - ego))
        crop = self._last_frame if self._last_frame is not None else np.zeros((224, 224, 3), np.uint8)
        return self._pip.update(nearest["id"], crop, state.ego_velocity)

    def _get_lane_error(self) -> float:
        if self._lane_detector is None or self._last_frame is None:
            return 0.0
        import cv2
        bgr = cv2.cvtColor(self._last_frame, cv2.COLOR_RGB2BGR)
        info = self._lane_detector.detect(bgr)
        return self._lane_detector.normalised_error(info)

    def _mock_obs(self) -> np.ndarray:
        return np.random.uniform(-0.1, 0.1, size=(LATENT_DIM,)).astype(np.float32)

    # ------------------------------------------------------------------
    # CARLA actor management
    # ------------------------------------------------------------------
    def _spawn_ego(self):
        bp_lib = self._world.get_blueprint_library()
        bp = bp_lib.filter("vehicle.lincoln.mkz_2020")[0]
        spawn_points = self._world.get_map().get_spawn_points()
        np.random.shuffle(spawn_points)
        for sp in spawn_points:
            try:
                self._vehicle = self._world.spawn_actor(bp, sp)
                self._prev_location = np.array([sp.location.x, sp.location.y])
                break
            except RuntimeError:
                continue

    def _attach_sensors(self):
        bp_lib = self._world.get_blueprint_library()
        # RGB Camera
        cam_bp = bp_lib.find("sensor.camera.rgb")
        cam_cfg = self.cfg["carla"]["camera"]
        cam_bp.set_attribute("image_size_x", str(cam_cfg["width"]))
        cam_bp.set_attribute("image_size_y", str(cam_cfg["height"]))
        cam_bp.set_attribute("fov", str(cam_cfg["fov"]))
        cam_transform = carla.Transform(carla.Location(x=1.5, z=2.4))
        self._camera = self._world.spawn_actor(cam_bp, cam_transform, attach_to=self._vehicle)
        self._camera.listen(self._on_camera)
        # Collision sensor
        coll_bp = bp_lib.find("sensor.other.collision")
        self._collision_sensor = self._world.spawn_actor(coll_bp, carla.Transform(), attach_to=self._vehicle)
        self._collision_sensor.listen(lambda e: setattr(self, "_collision_occurred", True))

    def _on_camera(self, image):
        import cv2
        arr = np.frombuffer(image.raw_data, dtype=np.uint8).reshape(
            image.height, image.width, 4
        )
        self._last_frame = arr[:, :, :3]   # BGRA → BGR, then we'll keep RGB later

    def _spawn_traffic(self):
        bp_lib = self._world.get_blueprint_library()
        spawn_pts = self._world.get_map().get_spawn_points()
        np.random.shuffle(spawn_pts)
        n_vehicles = self.cfg["carla"].get("num_vehicles", 20)
        traffic_manager = self._client.get_trafficmanager()
        for sp in spawn_pts[:n_vehicles]:
            bp = np.random.choice(bp_lib.filter("vehicle.*"))
            try:
                actor = self._world.spawn_actor(bp, sp)
                actor.set_autopilot(True, traffic_manager.get_port())
            except RuntimeError:
                pass

    def _apply_domain_randomization(self):
        dr = self.cfg.get("domain_rand", {})
        weather_presets = self.cfg["carla"].get("weather_presets", ["ClearNoon"])
        if np.random.random() < dr.get("weather_change_prob", 0.5):
            preset_name = np.random.choice(weather_presets)
            preset = getattr(carla.WeatherParameters, preset_name, carla.WeatherParameters.ClearNoon)
            self._world.set_weather(preset)

    def _destroy_actors(self):
        if self._camera:
            self._camera.destroy()
            self._camera = None
        if self._collision_sensor:
            self._collision_sensor.destroy()
            self._collision_sensor = None
        if self._vehicle:
            self._vehicle.destroy()
            self._vehicle = None
        if CARLA_AVAILABLE and self._world:
            for actor in self._world.get_actors().filter("vehicle.*"):
                actor.destroy()
            for actor in self._world.get_actors().filter("walker.*"):
                actor.destroy()
