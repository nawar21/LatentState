"""
Stage 7 — PPO Training on True Latent State
Stage 8 — CVaR-augmented PPO
Uses Stable-Baselines3 with a custom CVaR callback.
"""
from __future__ import annotations
import numpy as np
import torch
from pathlib import Path
from typing import Optional
from stable_baselines3 import PPO
from stable_baselines3.common.callbacks import BaseCallback, EvalCallback, CheckpointCallback
from stable_baselines3.common.vec_env import DummyVecEnv, VecNormalize
from stable_baselines3.common.monitor import Monitor


# ============================================================
# CVaR Callback (Stage 8)
# ============================================================

class CVaRCallback(BaseCallback):
    """
    Implements tail-risk CVaR weighting during PPO updates.
    After each rollout collection, re-weights the episode returns:
    - Sorts episode returns
    - Selects the worst alpha% 
    - Emphasises them via advantage re-scaling
    """

    def __init__(
        self,
        alpha: float = 0.05,
        beta: float = 0.5,
        verbose: int = 0,
    ):
        super().__init__(verbose)
        self.alpha = alpha      # worst fraction to focus on
        self.beta = beta        # blend weight: (1-β)·E[R] + β·CVaR

    def _on_rollout_end(self) -> None:
        """Called after rollout collection, before the policy update."""
        buffer = self.model.rollout_buffer
        returns = buffer.returns.flatten()          # (N,)
        n = len(returns)
        k = max(1, int(n * self.alpha))             # number of worst episodes

        # Find the CVaR threshold (VaR)
        sorted_returns = np.sort(returns)
        var_threshold = float(sorted_returns[k - 1])

        # Build per-step weight: higher weight for returns below threshold
        weights = np.where(returns <= var_threshold, 1.0 / (self.alpha + 1e-8), 1.0)
        # Blend: (1-β) * uniform + β * cvar_weights
        weights = (1 - self.beta) + self.beta * weights
        weights = weights / (weights.mean() + 1e-8)  # normalise

        # Re-scale advantages by these weights
        buffer.advantages *= weights.reshape(buffer.advantages.shape)

        if self.verbose > 0:
            cvar = float(sorted_returns[:k].mean())
            mean_r = float(returns.mean())
            print(f"[CVaR] Mean={mean_r:.3f} | VaR={var_threshold:.3f} | CVaR={cvar:.3f}")

    def _on_step(self) -> bool:
        return True


# ============================================================
# Logging Callback
# ============================================================

class RiskAwareLoggingCallback(BaseCallback):
    """Logs driving-specific metrics to TensorBoard."""

    def __init__(self, verbose: int = 0):
        super().__init__(verbose)
        self._ep_collisions = []
        self._ep_peek_rewards = []

    def _on_step(self) -> bool:
        infos = self.locals.get("infos", [])
        for info in infos:
            if "collision" in info:
                self._ep_collisions.append(float(info["collision"]))
            if "r_peek" in info:
                self._ep_peek_rewards.append(float(info["r_peek"]))
        return True

    def _on_rollout_end(self) -> None:
        if self._ep_collisions:
            self.logger.record("risk/collision_rate", np.mean(self._ep_collisions))
            self._ep_collisions.clear()
        if self._ep_peek_rewards:
            self.logger.record("risk/peek_reward", np.mean(self._ep_peek_rewards))
            self._ep_peek_rewards.clear()


# ============================================================
# PPO Trainer
# ============================================================

class PPOTrainer:
    """
    Unified PPO trainer supporting:
    - Standard PPO (Stage 7)
    - CVaR-augmented PPO (Stage 8)
    - Peeking reward shaping (Stage 9)
    """

    def __init__(
        self,
        env_factory,         # callable: () → gym.Env
        cfg: dict,
        use_cvar: bool = False,
        log_dir: str = "logs/ppo",
        checkpoint_dir: str = "checkpoints/ppo",
    ):
        self.cfg = cfg
        self.use_cvar = use_cvar
        self.log_dir = Path(log_dir)
        self.checkpoint_dir = Path(checkpoint_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)

        ppo_cfg = cfg.get("ppo", {})

        # Vectorised environment
        self.vec_env = DummyVecEnv([
            lambda: Monitor(env_factory())
        ])
        self.vec_env = VecNormalize(
            self.vec_env,
            norm_obs=True,
            norm_reward=True,
            clip_obs=10.0,
        )

        # Policy network (MLP on latent vector)
        policy_kwargs = dict(
            net_arch=dict(pi=[256, 256], vf=[256, 256]),
            activation_fn=torch.nn.GELU,
        )

        self.model = PPO(
            policy="MlpPolicy",
            env=self.vec_env,
            learning_rate=ppo_cfg.get("learning_rate", 3e-4),
            n_steps=ppo_cfg.get("n_steps", 2048),
            batch_size=ppo_cfg.get("batch_size", 256),
            n_epochs=ppo_cfg.get("n_epochs", 10),
            gamma=ppo_cfg.get("gamma", 0.99),
            gae_lambda=ppo_cfg.get("gae_lambda", 0.95),
            clip_range=ppo_cfg.get("clip_range", 0.2),
            ent_coef=ppo_cfg.get("ent_coef", 0.01),
            vf_coef=ppo_cfg.get("vf_coef", 0.5),
            max_grad_norm=ppo_cfg.get("max_grad_norm", 0.5),
            tensorboard_log=str(self.log_dir),
            policy_kwargs=policy_kwargs,
            verbose=1,
        )

    def train(
        self,
        total_timesteps: Optional[int] = None,
        eval_env_factory=None,
    ) -> None:
        ppo_cfg = self.cfg.get("ppo", {})
        n_steps = total_timesteps or ppo_cfg.get("total_timesteps", 1_000_000)

        callbacks = [RiskAwareLoggingCallback()]

        if self.use_cvar:
            cvar_cfg = self.cfg.get("cvar", {})
            callbacks.append(CVaRCallback(
                alpha=cvar_cfg.get("alpha", 0.05),
                beta=cvar_cfg.get("beta", 0.5),
                verbose=1,
            ))

        callbacks.append(CheckpointCallback(
            save_freq=10_000,
            save_path=str(self.checkpoint_dir),
            name_prefix="ppo",
        ))

        if eval_env_factory is not None:
            eval_env = DummyVecEnv([lambda: Monitor(eval_env_factory())])
            eval_env = VecNormalize(eval_env, norm_obs=True, norm_reward=False, training=False)
            callbacks.append(EvalCallback(
                eval_env,
                best_model_save_path=str(self.checkpoint_dir / "best"),
                log_path=str(self.log_dir),
                eval_freq=5000,
                n_eval_episodes=10,
                deterministic=True,
            ))

        self.model.learn(
            total_timesteps=n_steps,
            callback=callbacks,
            tb_log_name="ppo_cvar" if self.use_cvar else "ppo",
        )
        self.save()

    def save(self, path: Optional[str] = None) -> None:
        save_path = path or str(self.checkpoint_dir / "final_model")
        self.model.save(save_path)
        self.vec_env.save(str(self.checkpoint_dir / "vec_normalize.pkl"))
        print(f"[PPO] Saved model → {save_path}")

    def load(self, path: str) -> None:
        self.model = PPO.load(path, env=self.vec_env)
        print(f"[PPO] Loaded model from {path}")
